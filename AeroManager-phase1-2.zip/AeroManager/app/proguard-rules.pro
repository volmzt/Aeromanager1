# Aero Manager: default rules are enough for the current feature set.

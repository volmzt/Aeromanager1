package com.aerostudio.manager.ui

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.text.format.Formatter
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.aerostudio.manager.R
import com.aerostudio.manager.core.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

// ---------------------------------------------------------------- Tools

private class Planned(val title: Int, val icon: androidx.compose.ui.graphics.vector.ImageVector)

@Composable
fun ToolsScreen(openInFiles: (File) -> Unit) {
    var tool by rememberSaveable { mutableIntStateOf(0) }
    if (tool == 1) {
        BackHandler { tool = 0 }
        AccessGate { LargeFiles(onBack = { tool = 0 }, openInFiles = openInFiles) }
        return
    }
    val planned = listOf(
        Planned(R.string.tool_analyzer, Icons.Rounded.PieChart),
        Planned(R.string.tool_archive, Icons.Rounded.FolderZip),
        Planned(R.string.tool_apk, Icons.Rounded.Android),
        Planned(R.string.tool_apps, Icons.Rounded.Apps),
        Planned(R.string.tool_search, Icons.Rounded.Search),
        Planned(R.string.tool_trash, Icons.Rounded.Delete),
        Planned(R.string.tool_automation, Icons.Rounded.Schedule),
    )
    LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
        item { ScreenTitle(stringResource(R.string.nav_tools)) }
        item { SectionLabel(stringResource(R.string.tools_available)) }
        item {
            AeroRow(0, 1, onClick = { tool = 1 }) {
                IconTile(Icons.Rounded.Storage, MaterialTheme.colorScheme.primary)
                Column(Modifier.weight(1f)) {
                    Text(stringResource(R.string.tool_large), style = MaterialTheme.typography.bodyLarge)
                    Text(
                        stringResource(R.string.tool_large_sub),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Icon(Icons.Rounded.ChevronRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        item { SectionLabel(stringResource(R.string.tools_planned)) }
        itemsIndexed(planned) { i, t ->
            AeroRow(i, planned.size, modifier = Modifier.alpha(0.55f)) {
                IconTile(t.icon, MaterialTheme.colorScheme.onSurfaceVariant)
                Column(Modifier.weight(1f)) {
                    Text(stringResource(t.title), style = MaterialTheme.typography.bodyLarge)
                    Text(
                        stringResource(R.string.tool_soon),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }
}

@Composable
private fun LargeFiles(onBack: () -> Unit, openInFiles: (File) -> Unit) {
    val ctx = LocalContext.current
    val list by produceState<List<Found>?>(null) { value = withContext(Dispatchers.IO) { MediaInfo.largest(ctx, 40) } }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.padding(start = 8.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, stringResource(R.string.back)) }
            Text(stringResource(R.string.tool_large), style = MaterialTheme.typography.headlineMedium)
        }
        val l = list
        if (l == null) {
            LinearProgressIndicator(Modifier.fillMaxWidth())
        } else {
            LazyColumn(contentPadding = PaddingValues(top = 8.dp, bottom = 24.dp)) {
                itemsIndexed(l, key = { _, f -> f.file.absolutePath }) { i, f ->
                    AeroRow(i, l.size, onClick = { openInFiles(f.file.parentFile ?: f.file) }) {
                        KindTile(FileOps.kindOf(f.file))
                        Column(Modifier.weight(1f)) {
                            Text(f.file.name, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyLarge)
                            Text(
                                f.file.parent.orEmpty(), maxLines = 1, overflow = TextOverflow.Ellipsis,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        Text(Formatter.formatFileSize(ctx, f.size), style = MaterialTheme.typography.labelLarge)
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- Favorites

@Composable
fun FavoritesScreen(app: AppViewModel, prefs: Prefs, openInFiles: (File) -> Unit) {
    val ctx = LocalContext.current
    val favs = remember(prefs.favs) { prefs.favs.map { File(it) }.filter { it.exists() }.sortedBy { it.name.lowercase() } }
    LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
        item { ScreenTitle(stringResource(R.string.nav_favorites)) }
        if (favs.isEmpty()) {
            item {
                Text(
                    stringResource(R.string.favorites_empty),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 24.dp),
                )
            }
        }
        itemsIndexed(favs, key = { _, f -> f.absolutePath }) { i, f ->
            AeroRow(i, favs.size, onClick = {
                if (f.isDirectory) openInFiles(f)
                else if (!Opener.open(ctx, f)) Toast.makeText(ctx, R.string.no_app, Toast.LENGTH_SHORT).show()
            }) {
                KindTile(FileOps.kindOf(f))
                Column(Modifier.weight(1f)) {
                    Text(f.name, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyLarge)
                    Text(
                        f.parent.orEmpty(), maxLines = 1, overflow = TextOverflow.Ellipsis,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                IconButton({ app.toggleFavs(listOf(f.absolutePath)) }) {
                    Icon(Icons.Rounded.Star, stringResource(R.string.fav_toggle), tint = MaterialTheme.colorScheme.primary)
                }
            }
        }
    }
}

// ---------------------------------------------------------------- Settings

@Composable
private fun SwitchRow(i: Int, n: Int, title: Int, sub: Int?, checked: Boolean, onChange: (Boolean) -> Unit) {
    AeroRow(i, n, onClick = { onChange(!checked) }) {
        Column(Modifier.weight(1f)) {
            Text(stringResource(title), style = MaterialTheme.typography.bodyLarge)
            if (sub != null) Text(
                stringResource(sub),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        Switch(checked, onChange)
    }
}

@Composable
fun SettingsScreen(app: AppViewModel, prefs: Prefs) {
    val ctx = LocalContext.current
    val hasAccess = rememberHasAccess()
    val dynamicOk = Build.VERSION.SDK_INT >= 31
    val appearanceN = if (dynamicOk) 4 else 3
    val version = remember { runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }.getOrNull().orEmpty() }

    LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
        item { ScreenTitle(stringResource(R.string.nav_settings)) }

        item { SectionLabel(stringResource(R.string.appearance)) }
        item {
            AeroRow(0, appearanceN) {
                Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(stringResource(R.string.theme), style = MaterialTheme.typography.bodyLarge)
                    SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                        listOf(R.string.theme_system, R.string.theme_light, R.string.theme_dark).forEachIndexed { i, r ->
                            SegmentedButton(
                                selected = prefs.theme == i,
                                onClick = { app.set(K.THEME, i) },
                                shape = SegmentedButtonDefaults.itemShape(i, 3),
                            ) { Text(stringResource(r), maxLines = 1) }
                        }
                    }
                }
            }
        }
        item {
            AeroRow(1, appearanceN) {
                Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(stringResource(R.string.accent), style = MaterialTheme.typography.bodyLarge)
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Accents.forEachIndexed { i, a ->
                            val sel = prefs.accent == i
                            Box(
                                Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(a.dark)
                                    .then(if (sel) Modifier.border(BorderStroke(3.dp, MaterialTheme.colorScheme.onSurface), CircleShape) else Modifier)
                                    .alpha(if (prefs.dynamic && dynamicOk) 0.35f else 1f)
                                    .clickable { app.set(K.ACCENT, i) },
                                contentAlignment = Alignment.Center,
                            ) { if (sel) Icon(Icons.Rounded.Check, stringResource(a.name), tint = androidx.compose.ui.graphics.Color(0xFF0E1522)) }
                        }
                    }
                }
            }
        }
        if (dynamicOk) item { SwitchRow(2, appearanceN, R.string.dynamic_color, R.string.dynamic_color_sub, prefs.dynamic) { app.set(K.DYNAMIC, it) } }
        item { SwitchRow(appearanceN - 1, appearanceN, R.string.animations, null, prefs.anim) { app.set(K.ANIM, it) } }

        item { SectionLabel(stringResource(R.string.files_section)) }
        item { SwitchRow(0, 3, R.string.default_grid, null, prefs.grid) { app.set(K.GRID, it) } }
        item { SwitchRow(1, 3, R.string.hidden_files, null, prefs.hidden) { app.set(K.HIDDEN, it) } }
        item { SwitchRow(2, 3, R.string.thumbnails, null, prefs.thumbs) { app.set(K.THUMBS, it) } }

        item { SectionLabel(stringResource(R.string.system_section)) }
        item {
            AeroRow(0, 2, onClick = {
                val i = if (Build.VERSION.SDK_INT >= 30) Perm.settingsIntent(ctx)
                else Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}"))
                runCatching { ctx.startActivity(i) }
            }) {
                IconTile(Icons.Rounded.Lock, MaterialTheme.colorScheme.primary)
                Column(Modifier.weight(1f)) {
                    Text(stringResource(R.string.all_files_access), style = MaterialTheme.typography.bodyLarge)
                    Text(
                        stringResource(if (hasAccess) R.string.granted else R.string.not_granted),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
        item {
            AeroRow(1, 2, onClick = if (Build.VERSION.SDK_INT >= 33) ({
                runCatching { ctx.startActivity(Intent(Settings.ACTION_APP_LOCALE_SETTINGS, Uri.parse("package:${ctx.packageName}"))) }
            }) else null) {
                IconTile(Icons.Rounded.Language, MaterialTheme.colorScheme.primary)
                Column(Modifier.weight(1f)) {
                    Text(stringResource(R.string.language), style = MaterialTheme.typography.bodyLarge)
                    Text(
                        stringResource(if (Build.VERSION.SDK_INT >= 33) R.string.language_sub else R.string.language_old),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }

        item { SectionLabel(stringResource(R.string.about)) }
        item {
            AeroRow(0, 1) {
                Column(Modifier.weight(1f)) {
                    Text(stringResource(R.string.app_name), style = MaterialTheme.typography.bodyLarge)
                    Text(
                        stringResource(R.string.version_fmt, version),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }
}

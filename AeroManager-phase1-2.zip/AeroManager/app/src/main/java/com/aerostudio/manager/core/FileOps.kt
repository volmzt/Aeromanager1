package com.aerostudio.manager.core

import android.webkit.MimeTypeMap
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import java.io.File
import java.io.IOException
import java.nio.file.Files
import java.nio.file.StandardCopyOption

enum class Kind { FOLDER, IMAGE, VIDEO, AUDIO, DOC, APK, ARCHIVE, TEXT, OTHER }

enum class Conflict { KEEP_BOTH, REPLACE, SKIP }

data class Item(
    val file: File,
    val name: String,
    val isDir: Boolean,
    val size: Long,
    val modified: Long,
    val children: Int,
    val kind: Kind,
) {
    val path: String get() = file.absolutePath
}

data class Progress(
    val doneBytes: Long = 0,
    val totalBytes: Long = 0,
    val doneFiles: Int = 0,
    val totalFiles: Int = 0,
    val speed: Long = 0,
    val etaSec: Long = 0,
    val current: String = "",
    val move: Boolean = false,
)

data class OpError(val name: String, val code: Int, val detail: String?)

data class TransferResult(val done: Int, val skipped: Int, val errors: List<OpError>)

object FileOps {
    const val ERR_SPACE = 1
    const val ERR_SELF = 2
    const val ERR_IO = 3

    fun kindOf(file: File): Kind = kindOf(file.name, file.isDirectory)

    fun kindOf(name: String, isDir: Boolean): Kind {
        if (isDir) return Kind.FOLDER
        return when (name.substringAfterLast('.', "").lowercase()) {
            "jpg", "jpeg", "png", "gif", "webp", "bmp", "heic", "heif" -> Kind.IMAGE
            "mp4", "mkv", "webm", "avi", "mov", "3gp" -> Kind.VIDEO
            "mp3", "flac", "wav", "ogg", "m4a", "aac", "opus" -> Kind.AUDIO
            "pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "odt", "rtf" -> Kind.DOC
            "apk", "apks", "xapk" -> Kind.APK
            "zip", "rar", "7z", "tar", "gz", "bz2", "xz", "tgz" -> Kind.ARCHIVE
            "txt", "md", "log", "json", "xml", "csv", "html", "kt", "java", "py", "js", "css", "ini", "yml", "yaml" -> Kind.TEXT
            else -> Kind.OTHER
        }
    }

    fun mimeOf(f: File): String =
        MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase()) ?: "*/*"

    /** Returns null when the folder cannot be read (no permission). */
    fun list(dir: File, hidden: Boolean, sort: Int, asc: Boolean): List<Item>? {
        val arr = dir.listFiles() ?: return null
        val items = arr.map { f ->
            val d = f.isDirectory
            Item(f, f.name, d, if (d) 0L else f.length(), f.lastModified(), if (d) (f.list()?.size ?: 0) else 0, kindOf(f.name, d))
        }
        return arrange(items, hidden, sort, asc)
    }

    fun arrange(items: List<Item>, hidden: Boolean, sort: Int, asc: Boolean): List<Item> {
        val visible = items.filter { hidden || !it.name.startsWith(".") }
        val cmp: Comparator<Item> = when (sort) {
            1 -> compareBy<Item> { it.size }.thenBy { it.name.lowercase() }
            2 -> compareBy<Item> { it.modified }.thenBy { it.name.lowercase() }
            3 -> compareBy<Item> { it.kind.ordinal }.thenBy { it.name.lowercase() }
            else -> compareBy<Item> { it.name.lowercase() }
        }
        val sorted = visible.sortedWith(if (asc) cmp else cmp.reversed())
        val (dirs, files) = sorted.partition { it.isDir }
        return dirs + files
    }

    fun dirSize(f: File): Long =
        if (f.isDirectory) (f.listFiles()?.sumOf { dirSize(it) } ?: 0L) else f.length()

    fun uniqueName(dir: File, name: String): File {
        val first = File(dir, name)
        if (!first.exists()) return first
        val dot = name.lastIndexOf('.').takeIf { it > 0 }
        val base = if (dot != null) name.substring(0, dot) else name
        val ext = if (dot != null) name.substring(dot) else ""
        var i = 1
        var f: File
        do {
            f = File(dir, "$base ($i)$ext")
            i++
        } while (f.exists())
        return f
    }

    fun validName(name: String): Boolean =
        name.isNotBlank() && !name.contains('/') && name != "." && name != ".."

    fun rename(f: File, newName: String): Boolean {
        if (!validName(newName)) return false
        val t = File(f.parentFile, newName)
        return !t.exists() && f.renameTo(t)
    }

    fun deleteAll(files: List<File>): List<OpError> {
        val errs = mutableListOf<OpError>()
        files.forEach { if (!it.deleteRecursively()) errs.add(OpError(it.name, ERR_IO, null)) }
        return errs
    }

    // ---------- transfer (copy / move) with temp file + size verification ----------

    private class Stats(var bytes: Long = 0, var files: Int = 0)

    private class Res {
        var done = 0
        var skipped = 0
        val errors = mutableListOf<OpError>()
        fun err(n: String, c: Int, d: String?) { errors.add(OpError(n, c, d)) }
        fun result() = TransferResult(done, skipped, errors)
    }

    private class Tracker(val total: Stats, val move: Boolean, val cb: (Progress) -> Unit) {
        val start = System.nanoTime()
        var bytes = 0L
        var files = 0
        private var last = 0L
        fun emit(cur: String, force: Boolean = false) {
            val now = System.nanoTime()
            if (!force && now - last < 150_000_000L) return
            last = now
            val sec = (now - start) / 1e9
            val speed = if (sec > 0.3) (bytes / sec).toLong() else 0L
            val eta = if (speed > 0) (total.bytes - bytes).coerceAtLeast(0) / speed else 0L
            cb(Progress(bytes, total.bytes, files, total.files, speed, eta, cur, move))
        }
    }

    private fun measure(f: File, s: Stats) {
        if (f.isDirectory) f.listFiles()?.forEach { measure(it, s) } else { s.bytes += f.length(); s.files++ }
    }

    private fun resolve(dstDir: File, name: String, policy: Conflict, isDir: Boolean): File? {
        val t = File(dstDir, name)
        if (!t.exists()) return t
        return when (policy) {
            Conflict.SKIP -> if (isDir) t else null // folders are merged, files skipped
            Conflict.REPLACE -> t
            Conflict.KEEP_BOTH -> uniqueName(dstDir, name)
        }
    }

    suspend fun transfer(
        srcs: List<File>,
        dstDir: File,
        move: Boolean,
        policy: Conflict,
        onProgress: (Progress) -> Unit,
    ): TransferResult {
        val res = Res()
        val total = Stats()
        srcs.forEach { measure(it, total) }
        if (!move && dstDir.usableSpace < total.bytes) {
            res.err("", ERR_SPACE, null)
            return res.result()
        }
        val t = Tracker(total, move, onProgress)
        val dstPath = dstDir.canonicalPath
        for (src in srcs) {
            currentCoroutineContext().ensureActive()
            val srcPath = src.canonicalPath
            if (src.isDirectory && (dstPath == srcPath || dstPath.startsWith(srcPath + File.separator))) {
                res.err(src.name, ERR_SELF, null)
                continue
            }
            if (move) {
                if (src.parentFile?.canonicalPath == dstPath) { res.skipped++; continue }
                val target = resolve(dstDir, src.name, policy, src.isDirectory)
                if (target != null && !target.exists() && src.renameTo(target)) {
                    val s = Stats()
                    measure(target, s)
                    t.bytes += s.bytes; t.files += s.files; res.done += s.files
                    t.emit(src.name, true)
                    continue
                }
            }
            copyNode(src, dstDir, policy, t, res, move)
        }
        t.emit("", true)
        return res.result()
    }

    private suspend fun copyNode(src: File, dstDir: File, policy: Conflict, t: Tracker, res: Res, removeSrc: Boolean) {
        currentCoroutineContext().ensureActive()
        if (src.isDirectory) {
            val target = resolve(dstDir, src.name, policy, true) ?: return
            if (!target.exists() && !target.mkdirs()) { res.err(src.name, ERR_IO, "mkdir"); return }
            val before = res.errors.size
            src.listFiles()?.forEach { copyNode(it, target, policy, t, res, removeSrc) }
            if (removeSrc && res.errors.size == before) src.delete() // only removes the folder if it is empty
            return
        }
        val target = resolve(dstDir, src.name, policy, false)
        if (target == null) {
            res.skipped++
            t.bytes += src.length(); t.files++
            t.emit(src.name)
            return
        }
        val tmp = File(dstDir, ".${target.name}.aero-part")
        try {
            src.inputStream().use { input ->
                tmp.outputStream().use { output ->
                    val buf = ByteArray(256 * 1024)
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        output.write(buf, 0, n)
                        t.bytes += n
                        t.emit(src.name)
                        currentCoroutineContext().ensureActive()
                    }
                }
            }
            if (tmp.length() != src.length()) throw IOException("size mismatch")
            Files.move(tmp.toPath(), target.toPath(), StandardCopyOption.REPLACE_EXISTING)
            target.setLastModified(src.lastModified())
            t.files++
            res.done++
            if (removeSrc) src.delete()
        } catch (e: CancellationException) {
            tmp.delete()
            throw e
        } catch (e: Exception) {
            tmp.delete()
            res.err(src.name, ERR_IO, e.message)
        }
    }
}

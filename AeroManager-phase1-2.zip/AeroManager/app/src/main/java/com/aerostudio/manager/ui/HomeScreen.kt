package com.aerostudio.manager.ui

import android.os.Environment
import android.text.format.Formatter
import android.widget.Toast
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.aerostudio.manager.R
import com.aerostudio.manager.core.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.roundToInt

@Composable
fun HomeScreen(openInFiles: (File) -> Unit) {
    val ctx = LocalContext.current
    val has = rememberHasAccess()
    val root = remember { Environment.getExternalStorageDirectory() }
    val total = remember(has) { root.totalSpace }
    val free = remember(has) { root.freeSpace }
    val cats by produceState<Map<Cat, CatStat>?>(null, has) {
        value = if (has) withContext(Dispatchers.IO) { MediaInfo.categories(ctx) } else null
    }
    val recent by produceState(emptyList<Found>(), has) {
        value = if (has) withContext(Dispatchers.IO) { MediaInfo.recent(ctx, 8) } else emptyList()
    }
    val places = remember(has) {
        listOf(root) + listOf("Download", "DCIM", "Documents", "Music", "Movies", "Pictures")
            .map { File(root, it) }.filter { it.isDirectory }
    }

    LazyColumn(contentPadding = PaddingValues(bottom = 150.dp)) {
        item {
            Row(
                Modifier.padding(start = 20.dp, top = 12.dp, bottom = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Image(painterResource(R.drawable.ic_aero_logo), null, Modifier.size(40.dp))
                Text(stringResource(R.string.app_name), style = MaterialTheme.typography.headlineMedium)
            }
        }
        item { StorageCard(total, free) }
        if (!has) item { AccessPrompt(Modifier.fillMaxWidth()) }

        item { SectionLabel(stringResource(R.string.quick_access)) }
        itemsIndexed(places) { i, f ->
            val name = if (i == 0) stringResource(R.string.internal_storage) else f.name
            AeroRow(i, places.size, onClick = { openInFiles(f) }) {
                KindTile(Kind.FOLDER)
                Text(name, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
            }
        }

        val c = cats
        if (c != null) {
            val list = Cat.values().filter { c.getValue(it).count > 0 }
            item { SectionLabel(stringResource(R.string.categories)) }
            itemsIndexed(list) { i, cat ->
                val st = c.getValue(cat)
                AeroRow(i, list.size) {
                    KindTile(catKind(cat))
                    Column(Modifier.weight(1f)) {
                        Text(stringResource(catName(cat)), style = MaterialTheme.typography.bodyLarge)
                        Text(
                            "${st.count} · ${Formatter.formatFileSize(ctx, st.size)}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
        }

        if (recent.isNotEmpty()) {
            item { SectionLabel(stringResource(R.string.recent)) }
            itemsIndexed(recent) { i, r ->
                AeroRow(i, recent.size, onClick = {
                    if (!Opener.open(ctx, r.file)) Toast.makeText(ctx, R.string.no_app, Toast.LENGTH_SHORT).show()
                }) {
                    KindTile(FileOps.kindOf(r.file))
                    Column(Modifier.weight(1f)) {
                        Text(r.file.name, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyLarge)
                        Text(
                            Formatter.formatFileSize(ctx, r.size),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
        }
    }
}

fun catName(c: Cat): Int = when (c) {
    Cat.IMAGES -> R.string.cat_images
    Cat.VIDEO -> R.string.cat_video
    Cat.AUDIO -> R.string.cat_audio
    Cat.DOCS -> R.string.cat_docs
    Cat.APK -> R.string.cat_apk
    Cat.ARCHIVES -> R.string.cat_archives
    Cat.OTHER -> R.string.cat_other
}

@Composable
private fun StorageCard(total: Long, free: Long) {
    val ctx = LocalContext.current
    val used = (total - free).coerceAtLeast(0)
    val target = if (total > 0) used.toFloat() / total else 0f
    var go by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { go = true }
    val frac by animateFloatAsState(if (go) target else 0f, tween(1000), label = "ring")
    val track = MaterialTheme.colorScheme.surfaceContainerHighest
    val prim = MaterialTheme.colorScheme.primary
    Row(
        Modifier
            .padding(horizontal = 16.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(28.dp))
            .background(MaterialTheme.colorScheme.surfaceContainer)
            .padding(20.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(20.dp),
    ) {
        Box(Modifier.size(112.dp), contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize()) {
                val s = 12.dp.toPx()
                val sz = Size(size.width - s, size.height - s)
                val tl = Offset(s / 2, s / 2)
                drawArc(track, 0f, 360f, false, tl, sz, style = Stroke(s))
                if (frac > 0f) drawArc(prim, -90f, 360f * frac, false, tl, sz, style = Stroke(s, cap = StrokeCap.Round))
            }
            Text("${(frac * 100).roundToInt()}%", style = MaterialTheme.typography.headlineSmall)
        }
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(
                stringResource(R.string.storage_used_of, Formatter.formatFileSize(ctx, used), Formatter.formatFileSize(ctx, total)),
                style = MaterialTheme.typography.titleMedium,
            )
            Text(
                stringResource(R.string.storage_free, Formatter.formatFileSize(ctx, free)),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

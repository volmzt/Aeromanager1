package com.aerostudio.manager.core

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.aeroStore: DataStore<Preferences> by preferencesDataStore(name = "aero_settings")

/** theme: 0 system, 1 light, 2 dark. sort: 0 name, 1 size, 2 date, 3 type. */
data class Prefs(
    val theme: Int = 0,
    val accent: Int = 0,
    val dynamic: Boolean = false,
    val anim: Boolean = true,
    val grid: Boolean = false,
    val hidden: Boolean = false,
    val thumbs: Boolean = true,
    val sort: Int = 0,
    val asc: Boolean = true,
    val favs: Set<String> = emptySet(),
)

object K {
    val THEME = intPreferencesKey("theme")
    val ACCENT = intPreferencesKey("accent")
    val DYNAMIC = booleanPreferencesKey("dynamic")
    val ANIM = booleanPreferencesKey("anim")
    val GRID = booleanPreferencesKey("grid")
    val HIDDEN = booleanPreferencesKey("hidden")
    val THUMBS = booleanPreferencesKey("thumbs")
    val SORT = intPreferencesKey("sort")
    val ASC = booleanPreferencesKey("asc")
    val FAVS = stringSetPreferencesKey("favs")
}

class SettingsStore(context: Context) {
    private val store = context.applicationContext.aeroStore

    val flow: Flow<Prefs> = store.data.map { p ->
        Prefs(
            theme = p[K.THEME] ?: 0,
            accent = p[K.ACCENT] ?: 0,
            dynamic = p[K.DYNAMIC] ?: false,
            anim = p[K.ANIM] ?: true,
            grid = p[K.GRID] ?: false,
            hidden = p[K.HIDDEN] ?: false,
            thumbs = p[K.THUMBS] ?: true,
            sort = p[K.SORT] ?: 0,
            asc = p[K.ASC] ?: true,
            favs = p[K.FAVS] ?: emptySet(),
        )
    }

    suspend fun <T> set(key: Preferences.Key<T>, value: T) {
        store.edit { it[key] = value }
    }

    suspend fun toggleFavs(paths: Collection<String>) {
        store.edit { p ->
            val cur = (p[K.FAVS] ?: emptySet()).toMutableSet()
            // if every path is already a favorite, remove them; otherwise add all
            if (cur.containsAll(paths)) cur.removeAll(paths.toSet()) else cur.addAll(paths)
            p[K.FAVS] = cur
        }
    }
}

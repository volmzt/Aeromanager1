package com.aerostudio.manager.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.aerostudio.manager.core.Cat
import com.aerostudio.manager.core.Kind

@Composable
fun ScreenTitle(text: String, modifier: Modifier = Modifier) {
    Text(
        text,
        style = MaterialTheme.typography.displaySmall,
        modifier = modifier.padding(horizontal = 20.dp, vertical = 12.dp),
    )
}

@Composable
fun SectionLabel(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.labelLarge,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(start = 24.dp, top = 22.dp, bottom = 8.dp),
    )
}

/** Grouped-list shape: big radius on the outer corners of the group, small between items. */
fun groupShape(i: Int, n: Int): Shape {
    val big = 26.dp
    val small = 6.dp
    return RoundedCornerShape(
        topStart = if (i == 0) big else small,
        topEnd = if (i == 0) big else small,
        bottomStart = if (i == n - 1) big else small,
        bottomEnd = if (i == n - 1) big else small,
    )
}

@Composable
fun AeroRow(
    index: Int,
    count: Int,
    modifier: Modifier = Modifier,
    selected: Boolean = false,
    enabled: Boolean = true,
    onClick: (() -> Unit)? = null,
    onLongClick: (() -> Unit)? = null,
    content: @Composable RowScope.() -> Unit,
) {
    val bg by animateColorAsState(
        if (selected) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surfaceContainer,
        label = "rowbg",
    )
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val sc by animateFloatAsState(if (pressed) 0.97f else 1f, spring(dampingRatio = 0.6f, stiffness = 600f), label = "press")
    Row(
        modifier
            .padding(horizontal = 16.dp)
            .padding(top = if (index == 0) 0.dp else 3.dp)
            .fillMaxWidth()
            .graphicsLayer { scaleX = sc; scaleY = sc }
            .clip(groupShape(index, count))
            .background(bg)
            .then(
                if (onClick != null || onLongClick != null)
                    Modifier.combinedClickable(
                        interactionSource = src,
                        indication = LocalIndication.current,
                        enabled = enabled,
                        onClick = onClick ?: {},
                        onLongClick = onLongClick,
                    )
                else Modifier,
            )
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(16.dp),
        content = content,
    )
}

fun kindIcon(k: Kind): ImageVector = when (k) {
    Kind.FOLDER -> Icons.Rounded.Folder
    Kind.IMAGE -> Icons.Rounded.Image
    Kind.VIDEO -> Icons.Rounded.VideoFile
    Kind.AUDIO -> Icons.Rounded.AudioFile
    Kind.DOC -> Icons.Rounded.Description
    Kind.APK -> Icons.Rounded.Android
    Kind.ARCHIVE -> Icons.Rounded.FolderZip
    Kind.TEXT -> Icons.Rounded.Description
    Kind.OTHER -> Icons.Rounded.Description
}

@Composable
fun kindColor(k: Kind): Color = when (k) {
    Kind.FOLDER -> MaterialTheme.colorScheme.primary
    Kind.IMAGE -> Color(0xFF5E9BFF)
    Kind.VIDEO -> Color(0xFFB388FF)
    Kind.AUDIO -> Color(0xFFFF8A65)
    Kind.DOC -> Color(0xFFF2B600)
    Kind.APK -> Color(0xFF4CAF7D)
    Kind.ARCHIVE -> Color(0xFFEC6FA3)
    Kind.TEXT -> Color(0xFF90A4AE)
    Kind.OTHER -> Color(0xFF8E99AB)
}

fun catKind(c: Cat): Kind = when (c) {
    Cat.IMAGES -> Kind.IMAGE
    Cat.VIDEO -> Kind.VIDEO
    Cat.AUDIO -> Kind.AUDIO
    Cat.DOCS -> Kind.DOC
    Cat.APK -> Kind.APK
    Cat.ARCHIVES -> Kind.ARCHIVE
    Cat.OTHER -> Kind.OTHER
}

/** Flat one-colour icon (no tile background). */
@Composable
fun IconTile(icon: ImageVector, tint: Color, size: Dp = 44.dp, shape: Shape = RoundedCornerShape(14.dp)) {
    Box(Modifier.size(size), contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(size * 0.72f))
    }
}

@Composable
fun KindTile(kind: Kind, size: Dp = 44.dp) = IconTile(kindIcon(kind), kindColor(kind), size)

@Composable
fun CheckTile(size: Dp = 44.dp) {
    Box(
        Modifier.size(size).clip(CircleShape).background(MaterialTheme.colorScheme.primary),
        contentAlignment = Alignment.Center,
    ) { Icon(Icons.Rounded.Check, null, tint = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.size(size * 0.5f)) }
}

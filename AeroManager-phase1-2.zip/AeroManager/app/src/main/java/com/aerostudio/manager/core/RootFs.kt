package com.aerostudio.manager.core

import java.io.File
import java.util.concurrent.TimeUnit

/** File access through `su`. Only used when the user turns Root access on in settings. */
object RootFs {
    class Out(val code: Int, val text: String)

    private fun q(s: String) = "'" + s.replace("'", "'\\''") + "'"

    fun run(cmd: String, timeoutSec: Long = 30): Out = try {
        val p = ProcessBuilder("su", "-c", cmd).redirectErrorStream(true).start()
        val text = p.inputStream.bufferedReader().readText()
        if (!p.waitFor(timeoutSec, TimeUnit.SECONDS)) { p.destroyForcibly(); Out(-1, text) } else Out(p.exitValue(), text)
    } catch (e: Exception) {
        Out(-1, e.message ?: "")
    }

    @Volatile private var cached: Boolean? = null

    fun available(force: Boolean = false): Boolean {
        if (!force) cached?.let { return it }
        val r = run("id -u", 20)
        val ok = r.code == 0 && r.text.trim().endsWith("0")
        cached = ok
        return ok
    }

    fun exists(p: String) = run("test -e ${q(p)}").code == 0
    fun isDir(p: String) = run("test -d ${q(p)}").code == 0

    /** Lists a folder as root. Returns null if it could not be read. */
    fun list(dir: File): List<Item>? {
        val r = run("find ${q(dir.path)} -mindepth 1 -maxdepth 1 -exec stat -L -c '%F|%s|%Y|%n' {} \\;")
        val out = mutableListOf<Item>()
        for (line in r.text.lines()) {
            val parts = line.split('|', limit = 4)
            if (parts.size < 4) continue
            val isDir = parts[0] == "directory"
            val path = parts[3]
            val name = path.substringAfterLast('/')
            if (name.isEmpty()) continue
            out.add(
                Item(
                    File(path), name, isDir, if (isDir) 0L else (parts[1].toLongOrNull() ?: 0L),
                    (parts[2].toLongOrNull() ?: 0L) * 1000, -1, FileOps.kindOf(name, isDir),
                ),
            )
        }
        return if (out.isEmpty() && r.code != 0) null else out
    }

    fun delete(paths: List<String>): Boolean = run("rm -rf " + paths.joinToString(" ") { q(it) }).code == 0

    fun rename(from: File, newName: String): Boolean {
        if (!FileOps.validName(newName)) return false
        val t = File(from.parentFile, newName)
        return !exists(t.path) && run("mv ${q(from.path)} ${q(t.path)}").code == 0
    }

    fun create(path: String, folder: Boolean): Boolean =
        !exists(path) && run((if (folder) "mkdir " else "touch ") + q(path)).code == 0

    private fun uniqueTarget(dir: File, name: String): File {
        val dot = name.lastIndexOf('.').takeIf { it > 0 }
        val base = if (dot != null) name.substring(0, dot) else name
        val ext = if (dot != null) name.substring(dot) else ""
        var i = 1
        var f = File(dir, "$base ($i)$ext")
        while (exists(f.path) && i < 999) { i++; f = File(dir, "$base ($i)$ext") }
        return f
    }

    fun transfer(srcs: List<File>, dstDir: File, move: Boolean, policy: Conflict): TransferResult {
        var done = 0
        var skipped = 0
        val errs = mutableListOf<OpError>()
        for (src in srcs) {
            var target = File(dstDir, src.name)
            val taken = exists(target.path)
            if (taken) {
                when (policy) {
                    Conflict.SKIP -> { skipped++; continue }
                    Conflict.KEEP_BOTH -> target = uniqueTarget(dstDir, src.name)
                    Conflict.REPLACE -> {}
                }
            }
            val merge = taken && policy == Conflict.REPLACE && isDir(src.path)
            val cmd = when {
                move -> "mv -f ${q(src.path)} ${q(target.path)}"
                merge -> "cp -a ${q(src.path)}/. ${q(target.path)}/"
                else -> "cp -af ${q(src.path)} ${q(target.path)}"
            }
            val r = run(cmd, 600)
            if (r.code == 0) done++ else errs.add(OpError(src.name, FileOps.ERR_IO, r.text.trim().ifEmpty { null }))
        }
        return TransferResult(done, skipped, errs)
    }

    /** Copies a root-only file into the app cache so another app can open it. */
    fun readableCopy(src: File, cacheDir: File): File? {
        val out = File(cacheDir, "root_" + src.name)
        val ok = run("cat ${q(src.path)} > ${q(out.path)} && chmod 666 ${q(out.path)}").code == 0
        return if (ok) out else null
    }
}

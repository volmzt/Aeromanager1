package com.aerostudio.manager.core

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.ContentResolver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.provider.Settings
import androidx.core.content.FileProvider
import java.io.File

object Perm {
    fun has(c: Context): Boolean =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else c.checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED &&
            c.checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    fun settingsIntent(c: Context): Intent =
        Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:${c.packageName}"))
}

object Opener {
    private fun uri(c: Context, f: File): Uri = FileProvider.getUriForFile(c, "${c.packageName}.files", f)

    /** Returns false if no app can open the file. */
    fun open(c: Context, f: File): Boolean {
        val i = Intent(Intent.ACTION_VIEW).setDataAndType(uri(c, f), FileOps.mimeOf(f))
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        return try { c.startActivity(i); true } catch (e: ActivityNotFoundException) { false }
    }

    fun share(c: Context, files: List<File>) {
        val uris = ArrayList(files.map { uri(c, it) })
        val i = if (uris.size == 1) Intent(Intent.ACTION_SEND).putExtra(Intent.EXTRA_STREAM, uris[0])
        else Intent(Intent.ACTION_SEND_MULTIPLE).putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
        i.type = "*/*"
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        c.startActivity(Intent.createChooser(i, null))
    }
}

enum class Cat { IMAGES, VIDEO, AUDIO, DOCS, APK, ARCHIVES, OTHER }

class CatStat(var count: Int = 0, var size: Long = 0)

data class Found(val file: File, val size: Long, val modified: Long)

/** Real data from MediaStore (indexed files; may be approximate). */
object MediaInfo {
    private val uri: Uri = MediaStore.Files.getContentUri("external")
    private const val DATA = MediaStore.Files.FileColumns.DATA
    private const val SIZE = MediaStore.Files.FileColumns.SIZE
    private const val MIME = MediaStore.Files.FileColumns.MIME_TYPE
    private const val MTYPE = MediaStore.Files.FileColumns.MEDIA_TYPE
    private const val MOD = MediaStore.Files.FileColumns.DATE_MODIFIED

    private fun query(ctx: Context, proj: Array<String>, sel: String?, sortCol: String?, limit: Int): Cursor? {
        val b = Bundle()
        if (sel != null) b.putString(ContentResolver.QUERY_ARG_SQL_SELECTION, sel)
        if (sortCol != null) {
            b.putStringArray(ContentResolver.QUERY_ARG_SORT_COLUMNS, arrayOf(sortCol))
            b.putInt(ContentResolver.QUERY_ARG_SORT_DIRECTION, ContentResolver.QUERY_SORT_DIRECTION_DESCENDING)
        }
        if (limit > 0) b.putInt(ContentResolver.QUERY_ARG_LIMIT, limit)
        return try { ctx.contentResolver.query(uri, proj, b, null) } catch (e: Exception) { null }
    }

    fun categories(ctx: Context): Map<Cat, CatStat> {
        val m = Cat.values().associateWith { CatStat() }
        query(ctx, arrayOf(SIZE, MIME, MTYPE), "$SIZE > 0", null, 0)?.use { c ->
            while (c.moveToNext()) {
                val size = c.getLong(0)
                val mime = c.getString(1) ?: ""
                val cat = when (c.getInt(2)) {
                    MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE -> Cat.IMAGES
                    MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO -> Cat.VIDEO
                    MediaStore.Files.FileColumns.MEDIA_TYPE_AUDIO -> Cat.AUDIO
                    else -> when {
                        mime == "application/vnd.android.package-archive" -> Cat.APK
                        mime.contains("zip") || mime.contains("rar") || mime.contains("7z") ||
                            mime.contains("tar") || mime.contains("gzip") -> Cat.ARCHIVES
                        mime.startsWith("text/") || mime.contains("pdf") || mime.contains("word") ||
                            mime.contains("excel") || mime.contains("powerpoint") ||
                            mime.contains("officedocument") || mime.contains("opendocument") -> Cat.DOCS
                        else -> Cat.OTHER
                    }
                }
                m.getValue(cat).let { it.count++; it.size += size }
            }
        }
        return m
    }

    private const val FILTER = "$SIZE > 0 AND $DATA NOT LIKE '%/.%' AND $DATA NOT LIKE '%/Android/%'"

    private fun top(ctx: Context, sortCol: String, limit: Int): List<Found> {
        val out = mutableListOf<Found>()
        query(ctx, arrayOf(DATA, SIZE, MOD), FILTER, sortCol, limit)?.use { c ->
            while (c.moveToNext()) {
                val path = c.getString(0) ?: continue
                val f = File(path)
                if (f.isFile) out.add(Found(f, c.getLong(1), c.getLong(2) * 1000))
            }
        }
        return out
    }

    fun recent(ctx: Context, limit: Int) = top(ctx, MOD, limit)
    fun largest(ctx: Context, limit: Int) = top(ctx, SIZE, limit)
}

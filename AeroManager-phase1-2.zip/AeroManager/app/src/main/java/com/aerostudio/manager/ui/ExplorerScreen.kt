package com.aerostudio.manager.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.text.format.DateUtils
import android.text.format.Formatter
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.automirrored.rounded.Sort
import androidx.compose.material.icons.automirrored.rounded.ViewList
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.aerostudio.manager.R
import com.aerostudio.manager.core.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

private sealed interface Dlg {
    data object NewFolder : Dlg
    data object NewFile : Dlg
    data class Rename(val item: Item) : Dlg
    data object Delete : Dlg
    data object Conflict : Dlg
    data class Info(val item: Item) : Dlg
}

@Composable
fun ExplorerScreen(vm: ExplorerViewModel, app: AppViewModel, prefs: Prefs) {
    AccessGate { ExplorerContent(vm, app, prefs) }
}

@Composable
private fun ExplorerContent(vm: ExplorerViewModel, app: AppViewModel, prefs: Prefs) {
    val ctx = LocalContext.current
    val snack = remember { SnackbarHostState() }
    var dlg by remember { mutableStateOf<Dlg?>(null) }
    var sortMenu by remember { mutableStateOf(false) }
    var moreMenu by remember { mutableStateOf(false) }
    var selMenu by remember { mutableStateOf(false) }
    val selected = vm.selected
    val selecting = selected.isNotEmpty()

    LaunchedEffect(prefs.hidden, prefs.sort, prefs.asc) { vm.setOptions(prefs.hidden, prefs.sort, prefs.asc) }
    LaunchedEffect(Unit) { vm.events.collect { m -> snack.showSnackbar(ctx.getString(m.res, *m.args.toTypedArray())) } }
    BackHandler(enabled = selecting || !vm.atRoot()) { if (selecting) vm.clearSel() else vm.up() }

    fun copyPath(p: String) {
        ctx.getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("path", p))
        vm.notify(R.string.path_copied)
    }

    fun openItem(i: Item) {
        when {
            selecting -> vm.toggle(i)
            i.isDir -> vm.navigate(i.file)
            !Opener.open(ctx, i.file) -> vm.notify(R.string.no_app)
        }
    }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            if (selecting) {
                Row(Modifier.fillMaxWidth().padding(start = 8.dp, end = 8.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton({ vm.clearSel() }) { Icon(Icons.Rounded.Close, stringResource(R.string.cancel)) }
                    Text(stringResource(R.string.selected_count, selected.size), style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                    IconButton({ vm.selectAll() }) { Icon(Icons.Rounded.SelectAll, stringResource(R.string.select_all)) }
                    IconButton({ vm.invert() }) { Icon(Icons.Rounded.SwapHoriz, stringResource(R.string.invert)) }
                }
            } else {
                Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 8.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(stringResource(R.string.nav_files), style = MaterialTheme.typography.headlineLarge, modifier = Modifier.weight(1f))
                    IconButton({ app.set(K.GRID, !prefs.grid) }) {
                        Icon(
                            if (prefs.grid) Icons.AutoMirrored.Rounded.ViewList else Icons.Rounded.GridView,
                            stringResource(if (prefs.grid) R.string.view_list else R.string.view_grid),
                        )
                    }
                    Box {
                        IconButton({ sortMenu = true }) { Icon(Icons.AutoMirrored.Rounded.Sort, stringResource(R.string.sort)) }
                        DropdownMenu(sortMenu, { sortMenu = false }) {
                            listOf(R.string.sort_name, R.string.sort_size, R.string.sort_date, R.string.sort_type).forEachIndexed { i, r ->
                                DropdownMenuItem(
                                    text = { Text(stringResource(r)) },
                                    onClick = { app.set(K.SORT, i); sortMenu = false },
                                    trailingIcon = { if (prefs.sort == i) Icon(Icons.Rounded.Check, null) },
                                )
                            }
                            HorizontalDivider()
                            DropdownMenuItem(
                                text = { Text(stringResource(if (prefs.asc) R.string.sort_asc else R.string.sort_desc)) },
                                onClick = { app.set(K.ASC, !prefs.asc); sortMenu = false },
                            )
                        }
                    }
                    Box {
                        IconButton({ moreMenu = true }) { Icon(Icons.Rounded.MoreVert, stringResource(R.string.more)) }
                        DropdownMenu(moreMenu, { moreMenu = false }) {
                            DropdownMenuItem({ Text(stringResource(R.string.new_folder)) }, { moreMenu = false; dlg = Dlg.NewFolder },
                                leadingIcon = { Icon(Icons.Rounded.CreateNewFolder, null) })
                            DropdownMenuItem({ Text(stringResource(R.string.new_file)) }, { moreMenu = false; dlg = Dlg.NewFile },
                                leadingIcon = { Icon(Icons.Rounded.NoteAdd, null) })
                            DropdownMenuItem({ Text(stringResource(R.string.select_all)) }, { moreMenu = false; vm.selectAll() },
                                leadingIcon = { Icon(Icons.Rounded.SelectAll, null) })
                            DropdownMenuItem({ Text(stringResource(R.string.refresh)) }, { moreMenu = false; vm.reload() },
                                leadingIcon = { Icon(Icons.Rounded.Refresh, null) })
                            DropdownMenuItem({ Text(stringResource(R.string.copy_path)) }, { moreMenu = false; copyPath(vm.path.absolutePath) },
                                leadingIcon = { Icon(Icons.Rounded.ContentCopy, null) })
                            DropdownMenuItem({ Text(stringResource(R.string.hidden_files)) }, { moreMenu = false; app.set(K.HIDDEN, !prefs.hidden) },
                                trailingIcon = { if (prefs.hidden) Icon(Icons.Rounded.Check, null) })
                        }
                    }
                }
            }

            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton({ vm.goBack() }, enabled = vm.canBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, stringResource(R.string.back)) }
                IconButton({ vm.goForward() }, enabled = vm.canForward) { Icon(Icons.AutoMirrored.Rounded.ArrowForward, stringResource(R.string.forward)) }
                IconButton({ vm.up() }, enabled = !vm.atRoot()) { Icon(Icons.Rounded.ArrowUpward, stringResource(R.string.up)) }
                Breadcrumbs(vm, Modifier.weight(1f))
            }

            if (vm.loading) LinearProgressIndicator(Modifier.fillMaxWidth()) else Spacer(Modifier.height(4.dp))

            Box(Modifier.weight(1f)) {
                Crossfade(prefs.grid, animationSpec = if (prefs.anim) tween(220) else snap(), label = "view") { grid ->
                    if (vm.items.isEmpty() && !vm.loading) {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text(stringResource(R.string.empty_folder), color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    } else if (grid) {
                        LazyVerticalGrid(
                            columns = GridCells.Adaptive(108.dp),
                            contentPadding = PaddingValues(16.dp, 4.dp, 16.dp, 130.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            items(vm.items, key = { it.path }) { item ->
                                val sel = item.path in selected
                                val bg = if (sel) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surfaceContainer
                                Column(
                                    Modifier
                                        .clip(RoundedCornerShape(20.dp))
                                        .background(bg)
                                        .combinedClickable(onClick = { openItem(item) }, onLongClick = { vm.toggle(item) })
                                        .padding(12.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(8.dp),
                                ) {
                                    ItemIcon(item, sel, prefs.thumbs, 56.dp)
                                    Text(
                                        item.name, maxLines = 2, overflow = TextOverflow.Ellipsis,
                                        textAlign = TextAlign.Center, style = MaterialTheme.typography.bodySmall,
                                    )
                                }
                            }
                        }
                    } else {
                        LazyColumn(contentPadding = PaddingValues(top = 4.dp, bottom = 130.dp)) {
                            itemsIndexed(vm.items, key = { _, it -> it.path }) { i, item ->
                                val sel = item.path in selected
                                AeroRow(i, vm.items.size, selected = sel, onClick = { openItem(item) }, onLongClick = { vm.toggle(item) }) {
                                    ItemIcon(item, sel, prefs.thumbs)
                                    Column(Modifier.weight(1f)) {
                                        Text(item.name, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyLarge)
                                        Text(
                                            itemSubtitle(item), maxLines = 1,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        Column(Modifier.align(Alignment.BottomCenter).padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            AnimatedVisibility(selecting, enter = fadeIn() + expandVertically(), exit = fadeOut() + shrinkVertically()) {
                Surface(shape = RoundedCornerShape(28.dp), color = MaterialTheme.colorScheme.surfaceContainerHigh, shadowElevation = 6.dp) {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                        IconButton({ vm.setClip(false) }) { Icon(Icons.Rounded.ContentCopy, stringResource(R.string.copy)) }
                        IconButton({ vm.setClip(true) }) { Icon(Icons.Rounded.ContentCut, stringResource(R.string.cut)) }
                        IconButton({
                            val sel = vm.selectedItems()
                            if (sel.any { it.isDir }) vm.notify(R.string.folders_cant_share)
                            else { Opener.share(ctx, sel.map { it.file }); vm.clearSel() }
                        }) { Icon(Icons.Rounded.Share, stringResource(R.string.share)) }
                        IconButton({ dlg = Dlg.Delete }) { Icon(Icons.Rounded.Delete, stringResource(R.string.delete)) }
                        Box {
                            IconButton({ selMenu = true }) { Icon(Icons.Rounded.MoreVert, stringResource(R.string.more)) }
                            DropdownMenu(selMenu, { selMenu = false }) {
                                val sel = vm.selectedItems()
                                if (sel.size == 1) {
                                    DropdownMenuItem({ Text(stringResource(R.string.rename)) }, { selMenu = false; dlg = Dlg.Rename(sel[0]) },
                                        leadingIcon = { Icon(Icons.Rounded.DriveFileRenameOutline, null) })
                                    DropdownMenuItem({ Text(stringResource(R.string.info)) }, { selMenu = false; dlg = Dlg.Info(sel[0]) },
                                        leadingIcon = { Icon(Icons.Rounded.Info, null) })
                                    DropdownMenuItem({ Text(stringResource(R.string.copy_path)) }, { selMenu = false; copyPath(sel[0].path) },
                                        leadingIcon = { Icon(Icons.Rounded.ContentCopy, null) })
                                }
                                DropdownMenuItem({ Text(stringResource(R.string.fav_toggle)) }, {
                                    selMenu = false
                                    app.toggleFavs(sel.map { it.path })
                                    vm.clearSel()
                                }, leadingIcon = { Icon(Icons.Rounded.StarBorder, null) })
                            }
                        }
                    }
                }
            }
            val clip = vm.clip
            AnimatedVisibility(clip != null && !selecting, enter = fadeIn() + expandVertically(), exit = fadeOut() + shrinkVertically()) {
                if (clip != null) {
                    Surface(shape = RoundedCornerShape(28.dp), color = MaterialTheme.colorScheme.primaryContainer, shadowElevation = 6.dp) {
                        Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 8.dp, top = 6.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Rounded.ContentPaste, null, tint = MaterialTheme.colorScheme.onPrimaryContainer)
                            Text(
                                stringResource(if (clip.move) R.string.clip_move_n else R.string.clip_copy_n, clip.files.size),
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.weight(1f).padding(horizontal = 12.dp),
                            )
                            TextButton({ vm.clearClip() }) { Text(stringResource(R.string.cancel)) }
                            Button({ if (vm.conflictCount() > 0) dlg = Dlg.Conflict else vm.paste(Conflict.KEEP_BOTH) }) {
                                Text(stringResource(R.string.paste))
                            }
                        }
                    }
                }
            }
            SnackbarHost(snack)
        }
    }

    // ---------- dialogs ----------
    when (val d = dlg) {
        Dlg.NewFolder -> TextDialog(R.string.new_folder, "", R.string.create, { dlg = null }) { vm.create(it, true); dlg = null }
        Dlg.NewFile -> TextDialog(R.string.new_file, "", R.string.create, { dlg = null }) { vm.create(it, false); dlg = null }
        is Dlg.Rename -> TextDialog(R.string.rename, d.item.name, R.string.rename, { dlg = null }) { vm.rename(d.item, it); dlg = null }
        Dlg.Delete -> AlertDialog(
            onDismissRequest = { dlg = null },
            title = { Text(stringResource(R.string.delete_title)) },
            text = { Text(stringResource(R.string.delete_text, selected.size)) },
            confirmButton = { TextButton({ vm.deleteSelected(); dlg = null }) { Text(stringResource(R.string.delete)) } },
            dismissButton = { TextButton({ dlg = null }) { Text(stringResource(R.string.cancel)) } },
        )
        Dlg.Conflict -> AlertDialog(
            onDismissRequest = { dlg = null },
            title = { Text(stringResource(R.string.conflict_title)) },
            text = { Text(stringResource(R.string.conflict_text, vm.conflictCount())) },
            confirmButton = {
                Column(horizontalAlignment = Alignment.End) {
                    TextButton({ vm.paste(Conflict.REPLACE); dlg = null }) { Text(stringResource(R.string.replace)) }
                    TextButton({ vm.paste(Conflict.KEEP_BOTH); dlg = null }) { Text(stringResource(R.string.keep_both)) }
                    TextButton({ vm.paste(Conflict.SKIP); dlg = null }) { Text(stringResource(R.string.skip)) }
                }
            },
            dismissButton = { TextButton({ dlg = null }) { Text(stringResource(R.string.cancel)) } },
        )
        is Dlg.Info -> InfoDialog(d.item) { dlg = null }
        null -> {}
    }
    vm.progress?.let { p -> ProgressDialog(p) { vm.cancelTransfer() } }
    vm.report?.let { r -> ReportDialog(r) { vm.report = null } }
}

@Composable
private fun Breadcrumbs(vm: ExplorerViewModel, modifier: Modifier) {
    val rootPath = vm.root.absolutePath
    val crumbs = remember(vm.path) {
        val list = mutableListOf<File>()
        var f: File? = vm.path
        while (f != null) {
            list.add(0, f)
            if (f.absolutePath == rootPath) break
            f = f.parentFile
        }
        list
    }
    val state = rememberLazyListState()
    LaunchedEffect(crumbs) { if (crumbs.isNotEmpty()) state.animateScrollToItem(crumbs.lastIndex) }
    LazyRow(modifier, state = state, horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
        itemsIndexed(crumbs) { i, f ->
            val last = i == crumbs.lastIndex
            val label = if (f.absolutePath == rootPath) stringResource(R.string.internal_storage) else f.name
            Text(
                label,
                maxLines = 1,
                style = MaterialTheme.typography.labelLarge,
                color = if (last) MaterialTheme.colorScheme.onSecondaryContainer else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (last) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surfaceContainer)
                    .clickable(enabled = !last) { vm.navigate(f) }
                    .padding(horizontal = 12.dp, vertical = 7.dp),
            )
        }
    }
}

@Composable
private fun ItemIcon(i: Item, selected: Boolean, thumbs: Boolean, size: Dp = 44.dp) {
    when {
        selected -> CheckTile(size)
        thumbs && i.kind == Kind.IMAGE -> AsyncImage(
            model = i.file,
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.size(size).clip(RoundedCornerShape(14.dp)),
        )
        else -> KindTile(i.kind, size)
    }
}

@Composable
private fun itemSubtitle(i: Item): String {
    val ctx = LocalContext.current
    return remember(i.path, i.modified, i.size, i.children) {
        val date = DateUtils.formatDateTime(ctx, i.modified, DateUtils.FORMAT_SHOW_DATE or DateUtils.FORMAT_ABBREV_MONTH or DateUtils.FORMAT_SHOW_YEAR)
        val first = if (i.isDir) ctx.resources.getQuantityString(R.plurals.items, i.children, i.children)
        else Formatter.formatFileSize(ctx, i.size)
        "$first · $date"
    }
}

@Composable
private fun TextDialog(title: Int, initial: String, confirm: Int, onDismiss: () -> Unit, onOk: (String) -> Unit) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(title)) },
        text = {
            OutlinedTextField(
                value = text, onValueChange = { text = it }, singleLine = true,
                label = { Text(stringResource(R.string.name_label)) },
            )
        },
        confirmButton = { TextButton({ onOk(text.trim()) }, enabled = text.isNotBlank()) { Text(stringResource(confirm)) } },
        dismissButton = { TextButton(onDismiss) { Text(stringResource(R.string.cancel)) } },
    )
}

@Composable
private fun InfoDialog(item: Item, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val size by produceState<Long?>(if (item.isDir) null else item.size, item) {
        if (item.isDir) value = withContext(Dispatchers.IO) { FileOps.dirSize(item.file) }
    }
    val date = DateUtils.formatDateTime(ctx, item.modified, DateUtils.FORMAT_SHOW_DATE or DateUtils.FORMAT_SHOW_TIME or DateUtils.FORMAT_SHOW_YEAR)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(item.name, maxLines = 2, overflow = TextOverflow.Ellipsis) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                InfoLine(R.string.info_path, item.path)
                InfoLine(R.string.info_size, size?.let { Formatter.formatFileSize(ctx, it) } ?: stringResource(R.string.calculating))
                InfoLine(R.string.info_modified, date)
                InfoLine(R.string.info_type, if (item.isDir) stringResource(R.string.type_folder) else FileOps.mimeOf(item.file))
            }
        },
        confirmButton = { TextButton(onDismiss) { Text(stringResource(R.string.close)) } },
    )
}

@Composable
private fun InfoLine(label: Int, value: String) {
    Column {
        Text(stringResource(label), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
        Text(value, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun ProgressDialog(p: Progress, onCancel: () -> Unit) {
    val ctx = LocalContext.current
    val frac = if (p.totalBytes > 0) (p.doneBytes.toFloat() / p.totalBytes).coerceIn(0f, 1f) else 0f
    AlertDialog(
        onDismissRequest = {},
        title = { Text(stringResource(if (p.move) R.string.moving else R.string.copying)) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                LinearProgressIndicator(progress = { frac }, modifier = Modifier.fillMaxWidth())
                Text(stringResource(R.string.progress_files, p.doneFiles, p.totalFiles))
                Text(
                    stringResource(R.string.progress_speed, Formatter.formatFileSize(ctx, p.speed), DateUtils.formatElapsedTime(p.etaSec)),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Text(p.current, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = { TextButton(onCancel) { Text(stringResource(R.string.cancel_op)) } },
    )
}

@Composable
private fun ReportDialog(r: TransferResult, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.errors_title)) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(stringResource(R.string.done_summary, r.done, r.skipped))
                r.errors.forEach { e ->
                    val why = when (e.code) {
                        FileOps.ERR_SPACE -> stringResource(R.string.err_nospace)
                        FileOps.ERR_SELF -> stringResource(R.string.err_inself)
                        else -> e.detail ?: stringResource(R.string.err_io)
                    }
                    Text(if (e.name.isEmpty()) why else "${e.name}: $why", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                }
            }
        },
        confirmButton = { TextButton(onDismiss) { Text(stringResource(R.string.close)) } },
    )
}

package com.aerostudio.manager.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.text.format.DateUtils
import android.text.format.Formatter
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.OpenInNew
import androidx.compose.material.icons.automirrored.rounded.ViewList
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.aerostudio.manager.R
import com.aerostudio.manager.core.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Date

private sealed interface Dlg {
    data object NewFolder : Dlg
    data object NewFile : Dlg
    data class Rename(val item: Item) : Dlg
    data object Delete : Dlg
    data object Conflict : Dlg
    data class Info(val item: Item) : Dlg
}

private val DATE_FMT: java.text.DateFormat by lazy { java.text.DateFormat.getDateInstance(java.text.DateFormat.SHORT) }

/** go(n): 1 storage, 2 favorites, 3 tools, 4 settings */
@Composable
fun ExplorerScreen(vm: ExplorerViewModel, app: AppViewModel, prefs: Prefs, go: (Int) -> Unit) {
    AccessGate { ExplorerContent(vm, app, prefs, go) }
}

@Composable
private fun ExplorerContent(vm: ExplorerViewModel, app: AppViewModel, prefs: Prefs, go: (Int) -> Unit) {
    val ctx = LocalContext.current
    val snack = remember { SnackbarHostState() }
    var dlg by remember { mutableStateOf<Dlg?>(null) }
    var sheet by remember { mutableStateOf(false) }
    val selected = vm.selected
    val selecting = selected.isNotEmpty()

    LaunchedEffect(prefs.hidden, prefs.sort, prefs.asc, prefs.root) { vm.setOptions(prefs.hidden, prefs.sort, prefs.asc, prefs.root) }
    LaunchedEffect(Unit) { vm.events.collect { m -> snack.showSnackbar(ctx.getString(m.res, *m.args.toTypedArray())) } }
    BackHandler(enabled = selecting || vm.canBack) { if (selecting) vm.clearSel() else vm.goBack() }

    fun copyPath(p: String) {
        ctx.getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("path", p))
        vm.notify(R.string.path_copied)
    }

    fun openItem(i: Item) {
        when {
            selecting -> vm.toggle(i)
            i.isDir -> vm.navigate(i.file)
            vm.rootMode -> vm.openRoot(i)
            !Opener.open(ctx, i.file) -> vm.notify(R.string.no_app)
        }
    }

    fun longPress(i: Item) { vm.addToSelection(i); sheet = true }

    val navBottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            if (selecting) SelectionBar(selected.size, vm)
            else PathBar(vm, app, prefs, go, { dlg = Dlg.NewFolder }, { dlg = Dlg.NewFile }, { copyPath(vm.path.absolutePath) })

            if (vm.loading) LinearProgressIndicator(Modifier.fillMaxWidth()) else Spacer(Modifier.height(4.dp))

            Box(Modifier.weight(1f)) {
                FileContent(vm, prefs, selected, ::openItem, ::longPress) { app.setRoot(true) }
            }

            if (selecting) {
                ActionBar(
                    onCopy = { vm.setClip(false) },
                    onCut = { vm.setClip(true) },
                    onDelete = { dlg = Dlg.Delete },
                    onShare = {
                        val sel = vm.selectedItems()
                        if (vm.rootMode) vm.notify(R.string.no_app)
                        else if (sel.any { it.isDir }) vm.notify(R.string.folders_cant_share)
                        else { Opener.share(ctx, sel.map { it.file }); vm.clearSel() }
                    },
                    onMore = { sheet = true },
                )
            } else {
                vm.clip?.let { c ->
                    PasteBar(c, onCancel = { vm.clearClip() }) {
                        if (vm.conflictCount() > 0) dlg = Dlg.Conflict else vm.paste(Conflict.KEEP_BOTH)
                    }
                }
            }
        }

        if (!selecting && vm.clip == null) {
            FabMenu(navBottom, { dlg = Dlg.NewFolder }, { dlg = Dlg.NewFile })
        }
        SnackbarHost(snack, Modifier.align(Alignment.BottomCenter).padding(bottom = navBottom + 72.dp))
    }

    if (sheet && selecting) {
        ItemSheet(vm, app, prefs, onDismiss = { sheet = false }, onDlg = { sheet = false; dlg = it }, onCopyPath = { copyPath(it) })
    }

    // ---------- dialogs ----------
    when (val d = dlg) {
        Dlg.NewFolder -> TextDialog(R.string.new_folder, "", R.string.create, { dlg = null }) { vm.create(it, true); dlg = null }
        Dlg.NewFile -> TextDialog(R.string.new_file, "", R.string.create, { dlg = null }) { vm.create(it, false); dlg = null }
        is Dlg.Rename -> TextDialog(R.string.rename, d.item.name, R.string.rename, { dlg = null }) { vm.rename(d.item, it); dlg = null }
        Dlg.Delete -> AlertDialog(
            onDismissRequest = { dlg = null },
            title = { Text(stringResource(R.string.delete_title)) },
            text = { Text(stringResource(R.string.delete_text, selected.size)) },
            confirmButton = { TextButton({ vm.deleteSelected(); dlg = null }) { Text(stringResource(R.string.delete)) } },
            dismissButton = { TextButton({ dlg = null }) { Text(stringResource(R.string.cancel)) } },
        )
        Dlg.Conflict -> AlertDialog(
            onDismissRequest = { dlg = null },
            title = { Text(stringResource(R.string.conflict_title)) },
            text = { Text(stringResource(R.string.conflict_text, vm.conflictCount())) },
            confirmButton = {
                Column(horizontalAlignment = Alignment.End) {
                    TextButton({ vm.paste(Conflict.REPLACE); dlg = null }) { Text(stringResource(R.string.replace)) }
                    TextButton({ vm.paste(Conflict.KEEP_BOTH); dlg = null }) { Text(stringResource(R.string.keep_both)) }
                    TextButton({ vm.paste(Conflict.SKIP); dlg = null }) { Text(stringResource(R.string.skip)) }
                }
            },
            dismissButton = { TextButton({ dlg = null }) { Text(stringResource(R.string.cancel)) } },
        )
        is Dlg.Info -> InfoDialog(d.item) { dlg = null }
        null -> {}
    }
    vm.progress?.let { p -> ProgressDialog(p) { vm.cancelTransfer() } }
    vm.report?.let { r -> ReportDialog(r) { vm.report = null } }
}

// ------------------------------------------------------------------ top bars

@Composable
private fun PathBar(
    vm: ExplorerViewModel,
    app: AppViewModel,
    prefs: Prefs,
    go: (Int) -> Unit,
    onNewFolder: () -> Unit,
    onNewFile: () -> Unit,
    onCopyPath: () -> Unit,
) {
    var pathMenu by remember { mutableStateOf(false) }
    var moreMenu by remember { mutableStateOf(false) }
    var sortMenu by remember { mutableStateOf(false) }
    val title = when {
        vm.path.absolutePath == vm.home.absolutePath -> stringResource(R.string.internal_storage)
        vm.atRoot() -> "/"
        else -> vm.path.name
    }
    val chain = remember(vm.path) { generateSequence(vm.path.parentFile) { it.parentFile }.toList() }

    Surface(color = MaterialTheme.colorScheme.surfaceContainerHigh) {
        Row(Modifier.statusBarsPadding().height(64.dp).padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton({ vm.up() }, enabled = !vm.atRoot()) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, stringResource(R.string.up)) }
            Box(Modifier.weight(1f)) {
                Column(
                    Modifier.clip(RoundedCornerShape(10.dp)).clickable { pathMenu = true }.padding(horizontal = 8.dp, vertical = 4.dp),
                ) {
                    Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.titleMedium)
                    Text(
                        vm.path.absolutePath, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                DropdownMenu(pathMenu, { pathMenu = false }) {
                    DropdownMenuItem({ Text(stringResource(R.string.go_home)) }, { pathMenu = false; vm.navigate(vm.home) },
                        leadingIcon = { Icon(Icons.Rounded.Home, null) })
                    if (chain.isNotEmpty()) HorizontalDivider()
                    chain.forEach { f ->
                        DropdownMenuItem({ Text(f.absolutePath, maxLines = 1, overflow = TextOverflow.Ellipsis) }, { pathMenu = false; vm.navigate(f) })
                    }
                }
            }
            IconButton({ app.set(K.GRID, !prefs.grid) }) {
                Icon(
                    if (prefs.grid) Icons.AutoMirrored.Rounded.ViewList else Icons.Rounded.GridView,
                    stringResource(if (prefs.grid) R.string.view_list else R.string.view_grid),
                )
            }
            Box {
                IconButton({ moreMenu = true }) { Icon(Icons.Rounded.MoreVert, stringResource(R.string.more)) }
                DropdownMenu(moreMenu, { moreMenu = false }) {
                    DropdownMenuItem({ Text(stringResource(R.string.select_all)) }, { moreMenu = false; vm.selectAll() },
                        leadingIcon = { Icon(Icons.Rounded.SelectAll, null) })
                    DropdownMenuItem({ Text(stringResource(R.string.new_folder)) }, { moreMenu = false; onNewFolder() },
                        leadingIcon = { Icon(Icons.Rounded.CreateNewFolder, null) })
                    DropdownMenuItem({ Text(stringResource(R.string.new_file)) }, { moreMenu = false; onNewFile() },
                        leadingIcon = { Icon(Icons.Rounded.NoteAdd, null) })
                    DropdownMenuItem({ Text(stringResource(R.string.sort)) }, { moreMenu = false; sortMenu = true },
                        leadingIcon = { Icon(Icons.Rounded.SwapVert, null) })
                    DropdownMenuItem({ Text(stringResource(R.string.hidden_files)) }, { moreMenu = false; app.set(K.HIDDEN, !prefs.hidden) },
                        trailingIcon = { if (prefs.hidden) Icon(Icons.Rounded.Check, null) })
                    DropdownMenuItem({ Text(stringResource(R.string.refresh)) }, { moreMenu = false; vm.reload() },
                        leadingIcon = { Icon(Icons.Rounded.Refresh, null) })
                    DropdownMenuItem({ Text(stringResource(R.string.copy_path)) }, { moreMenu = false; onCopyPath() },
                        leadingIcon = { Icon(Icons.Rounded.ContentCopy, null) })
                    HorizontalDivider()
                    DropdownMenuItem({ Text(stringResource(R.string.nav_home)) }, { moreMenu = false; go(1) },
                        leadingIcon = { Icon(Icons.Rounded.Storage, null) })
                    DropdownMenuItem({ Text(stringResource(R.string.nav_favorites)) }, { moreMenu = false; go(2) },
                        leadingIcon = { Icon(Icons.Rounded.Star, null) })
                    DropdownMenuItem({ Text(stringResource(R.string.nav_tools)) }, { moreMenu = false; go(3) },
                        leadingIcon = { Icon(Icons.Rounded.Handyman, null) })
                    DropdownMenuItem({ Text(stringResource(R.string.nav_settings)) }, { moreMenu = false; go(4) },
                        leadingIcon = { Icon(Icons.Rounded.Settings, null) })
                }
                DropdownMenu(sortMenu, { sortMenu = false }) {
                    listOf(R.string.sort_name, R.string.sort_size, R.string.sort_date, R.string.sort_type).forEachIndexed { i, r ->
                        DropdownMenuItem(
                            text = { Text(stringResource(r)) },
                            onClick = { app.set(K.SORT, i); sortMenu = false },
                            trailingIcon = { if (prefs.sort == i) Icon(Icons.Rounded.Check, null) },
                        )
                    }
                    HorizontalDivider()
                    DropdownMenuItem(
                        text = { Text(stringResource(if (prefs.asc) R.string.sort_asc else R.string.sort_desc)) },
                        onClick = { app.set(K.ASC, !prefs.asc); sortMenu = false },
                    )
                }
            }
        }
    }
}

@Composable
private fun SelectionBar(n: Int, vm: ExplorerViewModel) {
    Surface(color = MaterialTheme.colorScheme.secondaryContainer) {
        Row(Modifier.statusBarsPadding().height(64.dp).padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton({ vm.clearSel() }) { Icon(Icons.Rounded.Close, stringResource(R.string.cancel)) }
            Text(stringResource(R.string.selected_count, n), style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
            IconButton({ vm.selectAll() }) { Icon(Icons.Rounded.SelectAll, stringResource(R.string.select_all)) }
            IconButton({ vm.invert() }) { Icon(Icons.Rounded.SwapHoriz, stringResource(R.string.invert)) }
        }
    }
}

// ------------------------------------------------------------------ bottom bars

@Composable
private fun BarButton(icon: ImageVector, label: Int, onClick: () -> Unit) {
    Column(
        Modifier.clip(RoundedCornerShape(12.dp)).clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(icon, null)
        Text(stringResource(label), style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
private fun ActionBar(onCopy: () -> Unit, onCut: () -> Unit, onDelete: () -> Unit, onShare: () -> Unit, onMore: () -> Unit) {
    Surface(color = MaterialTheme.colorScheme.surfaceContainerHigh) {
        Row(
            Modifier.navigationBarsPadding().fillMaxWidth().padding(vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
        ) {
            BarButton(Icons.Rounded.ContentCopy, R.string.copy, onCopy)
            BarButton(Icons.Rounded.ContentCut, R.string.cut, onCut)
            BarButton(Icons.Rounded.Delete, R.string.delete, onDelete)
            BarButton(Icons.Rounded.Share, R.string.share, onShare)
            BarButton(Icons.Rounded.MoreVert, R.string.more, onMore)
        }
    }
}

@Composable
private fun PasteBar(c: Clip, onCancel: () -> Unit, onPaste: () -> Unit) {
    Surface(color = MaterialTheme.colorScheme.surfaceContainerHigh) {
        Row(
            Modifier.navigationBarsPadding().fillMaxWidth().padding(start = 20.dp, end = 8.dp, top = 6.dp, bottom = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.Rounded.ContentPaste, null, tint = MaterialTheme.colorScheme.primary)
            Text(
                stringResource(if (c.move) R.string.clip_move_n else R.string.clip_copy_n, c.files.size),
                modifier = Modifier.weight(1f).padding(horizontal = 12.dp),
            )
            TextButton(onCancel) { Text(stringResource(R.string.cancel)) }
            Button(onPaste) { Text(stringResource(R.string.paste)) }
        }
    }
}

@Composable
private fun BoxScope.FabMenu(navBottom: Dp, onFolder: () -> Unit, onFile: () -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box(Modifier.align(Alignment.BottomEnd).padding(end = 16.dp, bottom = navBottom + 16.dp)) {
        FloatingActionButton(
            onClick = { open = true },
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary,
            shape = CircleShape,
        ) { Icon(Icons.Rounded.Add, null) }
        DropdownMenu(open, { open = false }) {
            DropdownMenuItem({ Text(stringResource(R.string.new_folder)) }, { open = false; onFolder() },
                leadingIcon = { Icon(Icons.Rounded.CreateNewFolder, null) })
            DropdownMenuItem({ Text(stringResource(R.string.new_file)) }, { open = false; onFile() },
                leadingIcon = { Icon(Icons.Rounded.NoteAdd, null) })
        }
    }
}

// ------------------------------------------------------------------ list

@Composable
private fun FileContent(
    vm: ExplorerViewModel,
    prefs: Prefs,
    selected: Set<String>,
    onOpen: (Item) -> Unit,
    onLong: (Item) -> Unit,
    onEnableRoot: () -> Unit,
) {
    val pad = navPadding(96.dp)
    when {
        vm.denied -> DeniedView(prefs.root, onEnableRoot)
        prefs.grid -> LazyVerticalGrid(
            columns = GridCells.Adaptive(104.dp),
            contentPadding = PaddingValues(12.dp, 4.dp, 12.dp, pad.calculateBottomPadding()),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            items(vm.items, key = { it.path }) { item ->
                val sel = item.path in selected
                Column(
                    Modifier
                        .clip(RoundedCornerShape(14.dp))
                        .background(if (sel) MaterialTheme.colorScheme.secondaryContainer else androidx.compose.ui.graphics.Color.Transparent)
                        .combinedClickable(onClick = { onOpen(item) }, onLongClick = { onLong(item) })
                        .padding(10.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    ItemIcon(item, sel, prefs.thumbs, 52.dp)
                    Text(item.name, maxLines = 2, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        else -> LazyColumn(contentPadding = pad) {
            if (!vm.atRoot()) {
                item(key = "..") {
                    AeroRow(0, 1, onClick = { vm.up() }) {
                        IconTile(Icons.Rounded.ArrowUpward, MaterialTheme.colorScheme.primary, 40.dp)
                        Text("..", style = MaterialTheme.typography.bodyLarge)
                    }
                }
            }
            if (vm.items.isEmpty() && !vm.loading) {
                item(key = "empty") {
                    Box(Modifier.fillMaxWidth().padding(48.dp), contentAlignment = Alignment.Center) {
                        Text(stringResource(R.string.empty_folder), color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            itemsIndexed(vm.items, key = { _, x -> x.path }) { i, item ->
                val sel = item.path in selected
                AeroRow(i, vm.items.size, selected = sel, onClick = { onOpen(item) }, onLongClick = { onLong(item) }) {
                    ItemIcon(item, sel, prefs.thumbs, 40.dp)
                    Column(Modifier.weight(1f)) {
                        Text(item.name, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyLarge)
                        Text(itemInfo(item), maxLines = 1, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Text(
                        remember(item.modified) { DATE_FMT.format(Date(item.modified)) },
                        style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }
}

@Composable
private fun DeniedView(rootOn: Boolean, onEnableRoot: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Icon(Icons.Rounded.Lock, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(40.dp))
        Spacer(Modifier.height(12.dp))
        Text(stringResource(R.string.no_access_title), style = MaterialTheme.typography.titleLarge, textAlign = TextAlign.Center)
        Spacer(Modifier.height(8.dp))
        Text(
            stringResource(if (rootOn) R.string.root_unavailable else R.string.no_access_text),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
        )
        if (!rootOn) {
            Spacer(Modifier.height(16.dp))
            Button(onEnableRoot) { Text(stringResource(R.string.root_enable)) }
        }
    }
}

@Composable
private fun ItemIcon(i: Item, selected: Boolean, thumbs: Boolean, size: Dp) {
    when {
        selected -> CheckTile(size)
        thumbs && i.kind == Kind.IMAGE && i.children >= 0 -> AsyncImage(
            model = i.file,
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.size(size).clip(RoundedCornerShape(8.dp)),
        )
        else -> KindTile(i.kind, size)
    }
}

@Composable
private fun itemInfo(i: Item): String {
    val ctx = LocalContext.current
    return remember(i.path, i.size, i.children) {
        when {
            i.isDir && i.children < 0 -> ctx.getString(R.string.type_folder)
            i.isDir -> ctx.resources.getQuantityString(R.plurals.items, i.children, i.children)
            else -> Formatter.formatFileSize(ctx, i.size)
        }
    }
}

// ------------------------------------------------------------------ bottom sheet (long press)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ItemSheet(
    vm: ExplorerViewModel,
    app: AppViewModel,
    prefs: Prefs,
    onDismiss: () -> Unit,
    onDlg: (Dlg) -> Unit,
    onCopyPath: (String) -> Unit,
) {
    val ctx = LocalContext.current
    val sel = vm.selectedItems()
    val single = sel.singleOrNull()
    val title = single?.name ?: stringResource(R.string.selected_count, sel.size)
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)) {
        Column(Modifier.navigationBarsPadding().verticalScroll(rememberScrollState())) {
            Text(
                title, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp),
            )
            HorizontalDivider()
            if (single != null && !single.isDir) {
                SheetRow(Icons.AutoMirrored.Rounded.OpenInNew, R.string.open) {
                    onDismiss()
                    if (vm.rootMode) vm.openRoot(single) else if (!Opener.open(ctx, single.file)) vm.notify(R.string.no_app)
                }
            }
            SheetRow(Icons.Rounded.ContentCopy, R.string.copy) { vm.setClip(false); onDismiss() }
            SheetRow(Icons.Rounded.ContentCut, R.string.cut) { vm.setClip(true); onDismiss() }
            SheetRow(Icons.Rounded.Delete, R.string.delete) { onDlg(Dlg.Delete) }
            if (single != null) {
                SheetRow(Icons.Rounded.DriveFileRenameOutline, R.string.rename) { onDlg(Dlg.Rename(single)) }
                SheetRow(Icons.Rounded.Info, R.string.info) { onDlg(Dlg.Info(single)) }
                SheetRow(Icons.Rounded.ContentCopy, R.string.copy_path) { onCopyPath(single.path); onDismiss() }
            }
            SheetRow(Icons.Rounded.StarBorder, R.string.fav_toggle) {
                app.toggleFavs(sel.map { it.path }); vm.clearSel(); onDismiss()
            }
            if (!vm.rootMode && sel.none { it.isDir }) {
                SheetRow(Icons.Rounded.Share, R.string.share) { Opener.share(ctx, sel.map { it.file }); vm.clearSel(); onDismiss() }
            }
        }
    }
}

@Composable
private fun SheetRow(icon: ImageVector, label: Int, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 24.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(20.dp),
    ) {
        Icon(icon, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(stringResource(label), style = MaterialTheme.typography.bodyLarge)
    }
}

// ------------------------------------------------------------------ dialogs

@Composable
private fun TextDialog(title: Int, initial: String, confirm: Int, onDismiss: () -> Unit, onOk: (String) -> Unit) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(title)) },
        text = {
            OutlinedTextField(
                value = text, onValueChange = { text = it }, singleLine = true,
                label = { Text(stringResource(R.string.name_label)) },
            )
        },
        confirmButton = { TextButton({ onOk(text.trim()) }, enabled = text.isNotBlank()) { Text(stringResource(confirm)) } },
        dismissButton = { TextButton(onDismiss) { Text(stringResource(R.string.cancel)) } },
    )
}

@Composable
private fun InfoDialog(item: Item, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val size by produceState<Long?>(if (item.isDir) null else item.size, item) {
        if (item.isDir) value = withContext(Dispatchers.IO) { FileOps.dirSize(item.file) }
    }
    val date = DateUtils.formatDateTime(ctx, item.modified, DateUtils.FORMAT_SHOW_DATE or DateUtils.FORMAT_SHOW_TIME or DateUtils.FORMAT_SHOW_YEAR)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(item.name, maxLines = 2, overflow = TextOverflow.Ellipsis) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                InfoLine(R.string.info_path, item.path)
                InfoLine(R.string.info_size, size?.let { Formatter.formatFileSize(ctx, it) } ?: stringResource(R.string.calculating))
                InfoLine(R.string.info_modified, date)
                InfoLine(R.string.info_type, if (item.isDir) stringResource(R.string.type_folder) else FileOps.mimeOf(item.file))
            }
        },
        confirmButton = { TextButton(onDismiss) { Text(stringResource(R.string.close)) } },
    )
}

@Composable
private fun InfoLine(label: Int, value: String) {
    Column {
        Text(stringResource(label), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
        Text(value, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun ProgressDialog(p: Progress, onCancel: () -> Unit) {
    val ctx = LocalContext.current
    val frac = if (p.totalBytes > 0) (p.doneBytes.toFloat() / p.totalBytes).coerceIn(0f, 1f) else 0f
    AlertDialog(
        onDismissRequest = {},
        title = { Text(stringResource(if (p.move) R.string.moving else R.string.copying)) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (p.totalBytes > 0) LinearProgressIndicator(progress = { frac }, modifier = Modifier.fillMaxWidth())
                else LinearProgressIndicator(Modifier.fillMaxWidth())
                if (p.totalFiles > 0) {
                    Text(stringResource(R.string.progress_files, p.doneFiles, p.totalFiles))
                    Text(
                        stringResource(R.string.progress_speed, Formatter.formatFileSize(ctx, p.speed), DateUtils.formatElapsedTime(p.etaSec)),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Text(p.current, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = { TextButton(onCancel) { Text(stringResource(R.string.cancel_op)) } },
    )
}

@Composable
private fun ReportDialog(r: TransferResult, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.errors_title)) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(stringResource(R.string.done_summary, r.done, r.skipped))
                r.errors.forEach { e ->
                    val why = when (e.code) {
                        FileOps.ERR_SPACE -> stringResource(R.string.err_nospace)
                        FileOps.ERR_SELF -> stringResource(R.string.err_inself)
                        else -> e.detail ?: stringResource(R.string.err_io)
                    }
                    Text(if (e.name.isEmpty()) why else "${e.name}: $why", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                }
            }
        },
        confirmButton = { TextButton(onDismiss) { Text(stringResource(R.string.close)) } },
    )
}

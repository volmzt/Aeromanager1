package com.aerostudio.manager.ui

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.os.Build
import androidx.annotation.StringRes
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import com.aerostudio.manager.R
import com.aerostudio.manager.core.Prefs

class Accent(
    @StringRes val name: Int,
    val dark: Color,
    val darkContainer: Color,
    val light: Color,
    val lightContainer: Color,
)

val Accents = listOf(
    Accent(R.string.accent_orange, Color(0xFFFF9F43), Color(0xFF4A2E12), Color(0xFFC25E00), Color(0xFFFFDDBF)),
    Accent(R.string.accent_blue, Color(0xFF8AB4F8), Color(0xFF283B5C), Color(0xFF1A5FD0), Color(0xFFD6E3FF)),
    Accent(R.string.accent_green, Color(0xFF7FD8A6), Color(0xFF1F4A38), Color(0xFF1B7A4A), Color(0xFFCFF5DF)),
    Accent(R.string.accent_violet, Color(0xFFC3A6FF), Color(0xFF3A2D5E), Color(0xFF6B45D1), Color(0xFFE8DDFF)),
    Accent(R.string.accent_pink, Color(0xFFFF9CC2), Color(0xFF5E2B44), Color(0xFFC2185B), Color(0xFFFFD8E8)),
)

private fun Context.findActivity(): Activity? {
    var c: Context? = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

@Composable
fun AeroTheme(prefs: Prefs, content: @Composable () -> Unit) {
    val dark = when (prefs.theme) {
        1 -> false
        2 -> true
        else -> isSystemInDarkTheme()
    }
    val ctx = LocalContext.current
    val a = Accents[prefs.accent.coerceIn(0, Accents.lastIndex)]
    val scheme = when {
        prefs.dynamic && Build.VERSION.SDK_INT >= 31 ->
            if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        dark -> darkColorScheme(
            primary = a.dark, onPrimary = Color(0xFF241100),
            primaryContainer = a.darkContainer, onPrimaryContainer = Color(0xFFFFE6CC),
            secondary = a.dark, secondaryContainer = a.darkContainer, onSecondaryContainer = Color(0xFFFFE6CC),
            background = Color(0xFF101012), onBackground = Color(0xFFECECEF),
            surface = Color(0xFF101012), onSurface = Color(0xFFECECEF), onSurfaceVariant = Color(0xFFA9A9B1),
            surfaceContainerLowest = Color(0xFF0A0A0B), surfaceContainerLow = Color(0xFF151517),
            surfaceContainer = Color(0xFF1C1C1F), surfaceContainerHigh = Color(0xFF252528),
            surfaceContainerHighest = Color(0xFF2F2F33),
            outline = Color(0xFF5E5E66), outlineVariant = Color(0xFF2E2E33), error = Color(0xFFFF8A80),
        )
        else -> lightColorScheme(
            primary = a.light, onPrimary = Color.White,
            primaryContainer = a.lightContainer, onPrimaryContainer = Color(0xFF111827),
            secondary = a.light, secondaryContainer = a.lightContainer, onSecondaryContainer = Color(0xFF111827),
            background = Color(0xFFF4F5F9), onBackground = Color(0xFF16181D),
            surface = Color(0xFFF4F5F9), onSurface = Color(0xFF16181D), onSurfaceVariant = Color(0xFF5C606B),
            surfaceContainerLowest = Color.White, surfaceContainerLow = Color(0xFFF8F9FC),
            surfaceContainer = Color.White, surfaceContainerHigh = Color(0xFFEDEFF5),
            surfaceContainerHighest = Color(0xFFE3E6EE),
            outline = Color(0xFF8A8E99), outlineVariant = Color(0xFFD9DCE5),
        )
    }
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val w = view.context.findActivity()?.window
            if (w != null) {
                val c = WindowCompat.getInsetsController(w, view)
                c.isAppearanceLightStatusBars = !dark
                c.isAppearanceLightNavigationBars = !dark
            }
        }
    }
    MaterialTheme(colorScheme = scheme, content = content)
}

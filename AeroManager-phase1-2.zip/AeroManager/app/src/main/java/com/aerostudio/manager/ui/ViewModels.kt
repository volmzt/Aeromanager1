package com.aerostudio.manager.ui

import android.app.Application
import android.os.Environment
import androidx.annotation.StringRes
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.datastore.preferences.core.Preferences
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.aerostudio.manager.R
import com.aerostudio.manager.core.*
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val store = SettingsStore(app)
    val prefs: StateFlow<Prefs> = store.flow.stateIn(viewModelScope, SharingStarted.Eagerly, Prefs())

    fun <T> set(key: Preferences.Key<T>, value: T) {
        viewModelScope.launch { store.set(key, value) }
    }

    fun toggleFavs(paths: Collection<String>) {
        viewModelScope.launch { store.toggleFavs(paths) }
    }
}

class Msg(@StringRes val res: Int, val args: List<Any> = emptyList())

class Clip(val files: List<File>, val move: Boolean)

class ExplorerViewModel(app: Application) : AndroidViewModel(app) {
    val root: File = Environment.getExternalStorageDirectory()

    var path by mutableStateOf(root); private set
    var items by mutableStateOf<List<Item>>(emptyList()); private set
    var loading by mutableStateOf(false); private set
    var selected by mutableStateOf<Set<String>>(emptySet()); private set
    var clip by mutableStateOf<Clip?>(null); private set
    var progress by mutableStateOf<Progress?>(null); private set
    var report by mutableStateOf<TransferResult?>(null)
    var canBack by mutableStateOf(false); private set
    var canForward by mutableStateOf(false); private set

    val events: SharedFlow<Msg> get() = _events
    private val _events = MutableSharedFlow<Msg>(extraBufferCapacity = 8)

    private val back = ArrayDeque<File>()
    private val fwd = ArrayDeque<File>()
    private var hidden = false
    private var sort = 0
    private var asc = true
    private var started = false
    private var job: Job? = null
    private var loadJob: Job? = null

    private fun say(@StringRes res: Int, vararg args: Any) { _events.tryEmit(Msg(res, args.toList())) }

    private fun sync() { canBack = back.isNotEmpty(); canForward = fwd.isNotEmpty() }

    fun setOptions(h: Boolean, s: Int, a: Boolean) {
        if (started && h == hidden && s == sort && a == asc) return
        hidden = h; sort = s; asc = a; started = true
        reload()
    }

    fun reload() {
        loadJob?.cancel()
        loading = true
        val dir = path
        val h = hidden; val s = sort; val a = asc
        loadJob = viewModelScope.launch {
            val r = withContext(Dispatchers.IO) { FileOps.list(dir, h, s, a) }
            items = r
            loading = false
            val paths = r.map { it.path }.toSet()
            selected = selected.filter { it in paths }.toSet()
        }
    }

    // ----- navigation -----
    fun navigate(dir: File) {
        if (dir.absolutePath == path.absolutePath) return
        back.addLast(path); fwd.clear()
        path = dir; selected = emptySet()
        sync(); reload()
    }

    fun openPath(f: File) { navigate(if (f.isDirectory) f else f.parentFile ?: root) }

    fun goBack() {
        if (back.isEmpty()) return
        fwd.addLast(path); path = back.removeLast(); selected = emptySet()
        sync(); reload()
    }

    fun goForward() {
        if (fwd.isEmpty()) return
        back.addLast(path); path = fwd.removeLast(); selected = emptySet()
        sync(); reload()
    }

    fun atRoot(): Boolean = path.absolutePath == root.absolutePath

    fun up(): Boolean {
        if (atRoot()) return false
        val p = path.parentFile ?: return false
        navigate(p)
        return true
    }

    // ----- selection -----
    fun toggle(i: Item) { selected = if (i.path in selected) selected - i.path else selected + i.path }
    fun selectAll() { selected = items.map { it.path }.toSet() }
    fun invert() { selected = items.map { it.path }.toSet() - selected }
    fun clearSel() { selected = emptySet() }
    fun selectedItems(): List<Item> = items.filter { it.path in selected }

    // ----- clipboard & transfer -----
    fun setClip(move: Boolean) {
        val files = selectedItems().map { it.file }
        if (files.isEmpty()) return
        clip = Clip(files, move); clearSel()
    }

    fun clearClip() { clip = null }

    fun conflictCount(): Int = clip?.files?.count { File(path, it.name).exists() } ?: 0

    fun paste(policy: Conflict) {
        val c = clip ?: return
        val dst = path
        progress = Progress(move = c.move)
        job = viewModelScope.launch {
            var res: TransferResult? = null
            try {
                res = withContext(Dispatchers.IO) { FileOps.transfer(c.files, dst, c.move, policy) { progress = it } }
            } catch (e: CancellationException) {
                say(R.string.op_cancelled)
            } finally {
                progress = null
                reload()
            }
            res?.let { r ->
                if (c.move && r.errors.isEmpty()) clip = null
                if (r.errors.isEmpty()) say(R.string.done_summary, r.done, r.skipped) else report = r
            }
        }
    }

    fun cancelTransfer() { job?.cancel() }

    // ----- simple ops -----
    fun deleteSelected() {
        val files = selectedItems().map { it.file }
        clearSel()
        viewModelScope.launch {
            val errs = withContext(Dispatchers.IO) { FileOps.deleteAll(files) }
            reload()
            if (errs.isEmpty()) say(R.string.deleted, files.size) else report = TransferResult(files.size - errs.size, 0, errs)
        }
    }

    fun rename(item: Item, name: String) {
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) { FileOps.rename(item.file, name) }
            clearSel(); reload()
            if (!ok) say(R.string.rename_failed)
        }
    }

    fun create(name: String, folder: Boolean) {
        if (!FileOps.validName(name)) { say(R.string.invalid_name); return }
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) {
                val f = File(path, name)
                if (f.exists()) false else if (folder) f.mkdir() else runCatching { f.createNewFile() }.getOrDefault(false)
            }
            reload()
            if (!ok) say(R.string.exists_already)
        }
    }

    fun notify(@StringRes res: Int, vararg args: Any) = say(res, *args)
}

package com.aerostudio.manager.ui

import android.app.Application
import android.os.Environment
import androidx.annotation.StringRes
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.datastore.preferences.core.Preferences
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.aerostudio.manager.R
import com.aerostudio.manager.core.*
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val store = SettingsStore(app)
    val prefs: StateFlow<Prefs> = store.flow.stateIn(viewModelScope, SharingStarted.Eagerly, Prefs())

    /** 0 unknown, 1 root granted, 2 root unavailable or denied */
    var rootState by mutableIntStateOf(0); private set

    fun <T> set(key: Preferences.Key<T>, value: T) {
        viewModelScope.launch { store.set(key, value) }
    }

    fun toggleFavs(paths: Collection<String>) {
        viewModelScope.launch { store.toggleFavs(paths) }
    }

    fun setRoot(on: Boolean) {
        set(K.ROOT, on)
        if (!on) { rootState = 0; return }
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) { RootFs.available(true) }
            rootState = if (ok) 1 else 2
        }
    }
}

class Msg(@StringRes val res: Int, val args: List<Any> = emptyList())

class Clip(val files: List<File>, val move: Boolean, val root: Boolean)

class ExplorerViewModel(app: Application) : AndroidViewModel(app) {
    val home: File = Environment.getExternalStorageDirectory()

    var path by mutableStateOf(home); private set
    var items by mutableStateOf<List<Item>>(emptyList()); private set
    var loading by mutableStateOf(false); private set
    var denied by mutableStateOf(false); private set
    var rootMode by mutableStateOf(false); private set
    var selected by mutableStateOf<Set<String>>(emptySet()); private set
    var clip by mutableStateOf<Clip?>(null); private set
    var progress by mutableStateOf<Progress?>(null); private set
    var report by mutableStateOf<TransferResult?>(null)
    var canBack by mutableStateOf(false); private set

    val events: SharedFlow<Msg> get() = _events
    private val _events = MutableSharedFlow<Msg>(extraBufferCapacity = 8)

    private val back = ArrayDeque<File>()
    private val fwd = ArrayDeque<File>()
    private var hidden = false
    private var sort = 0
    private var asc = true
    private var rootOn = false
    private var started = false
    private var job: Job? = null
    private var loadJob: Job? = null

    private fun say(@StringRes res: Int, vararg args: Any) { _events.tryEmit(Msg(res, args.toList())) }

    private fun sync() { canBack = back.isNotEmpty() }

    fun setOptions(h: Boolean, s: Int, a: Boolean, r: Boolean) {
        if (started && h == hidden && s == sort && a == asc && r == rootOn) return
        hidden = h; sort = s; asc = a; rootOn = r; started = true
        reload()
    }

    private class Loaded(val items: List<Item>, val denied: Boolean, val root: Boolean)

    private fun loadDir(dir: File, h: Boolean, s: Int, a: Boolean, useRoot: Boolean): Loaded {
        val std = FileOps.list(dir, h, s, a)
        if (std != null && !(std.isEmpty() && useRoot && !dir.canRead())) return Loaded(std, false, false)
        if (useRoot && RootFs.available()) {
            val l = RootFs.list(dir)
            if (l != null) return Loaded(FileOps.arrange(l, h, s, a), false, true)
        }
        return Loaded(emptyList(), true, false)
    }

    fun reload() {
        loadJob?.cancel()
        loading = true
        val dir = path
        val h = hidden; val s = sort; val a = asc; val r = rootOn
        loadJob = viewModelScope.launch {
            val res = withContext(Dispatchers.IO) { loadDir(dir, h, s, a, r) }
            items = res.items
            denied = res.denied
            rootMode = res.root
            loading = false
            val paths = res.items.map { it.path }.toSet()
            selected = selected.filter { it in paths }.toSet()
        }
    }

    // ----- navigation -----
    fun navigate(dir: File) {
        if (dir.absolutePath == path.absolutePath) return
        back.addLast(path); fwd.clear()
        path = dir; selected = emptySet()
        sync(); reload()
    }

    fun openPath(f: File) { navigate(if (f.isDirectory) f else f.parentFile ?: home) }

    fun goBack() {
        if (back.isEmpty()) return
        fwd.addLast(path); path = back.removeLast(); selected = emptySet()
        sync(); reload()
    }

    fun atRoot(): Boolean = path.parentFile == null

    fun up(): Boolean {
        val p = path.parentFile ?: return false
        navigate(p)
        return true
    }

    // ----- selection -----
    fun toggle(i: Item) { selected = if (i.path in selected) selected - i.path else selected + i.path }
    fun addToSelection(i: Item) { if (i.path !in selected) selected = selected + i.path }
    fun selectAll() { selected = items.map { it.path }.toSet() }
    fun invert() { selected = items.map { it.path }.toSet() - selected }
    fun clearSel() { selected = emptySet() }
    fun selectedItems(): List<Item> = items.filter { it.path in selected }

    // ----- clipboard & transfer -----
    fun setClip(move: Boolean) {
        val files = selectedItems().map { it.file }
        if (files.isEmpty()) return
        clip = Clip(files, move, rootMode); clearSel()
    }

    fun clearClip() { clip = null }

    /** Root pastes never overwrite silently: they always keep both. */
    fun conflictCount(): Int =
        if (rootMode) 0 else clip?.files?.count { File(path, it.name).exists() } ?: 0

    fun paste(policy: Conflict) {
        val c = clip ?: return
        val dst = path
        val viaRoot = rootMode || c.root
        progress = Progress(move = c.move)
        job = viewModelScope.launch {
            var res: TransferResult? = null
            try {
                res = withContext(Dispatchers.IO) {
                    if (viaRoot) RootFs.transfer(c.files, dst, c.move, if (rootMode) Conflict.KEEP_BOTH else policy)
                    else FileOps.transfer(c.files, dst, c.move, policy) { progress = it }
                }
            } catch (e: CancellationException) {
                say(R.string.op_cancelled)
            } finally {
                progress = null
                reload()
            }
            res?.let { r ->
                if (c.move && r.errors.isEmpty()) clip = null
                if (r.errors.isEmpty()) say(R.string.done_summary, r.done, r.skipped) else report = r
            }
        }
    }

    fun cancelTransfer() { job?.cancel() }

    // ----- simple ops -----
    fun deleteSelected() {
        val files = selectedItems().map { it.file }
        val viaRoot = rootMode
        clearSel()
        viewModelScope.launch {
            val errs = withContext(Dispatchers.IO) {
                if (viaRoot) { if (RootFs.delete(files.map { it.path })) emptyList() else listOf(OpError("", FileOps.ERR_IO, null)) }
                else FileOps.deleteAll(files)
            }
            reload()
            if (errs.isEmpty()) say(R.string.deleted, files.size) else report = TransferResult(files.size - errs.size, 0, errs)
        }
    }

    fun rename(item: Item, name: String) {
        val viaRoot = rootMode
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) { if (viaRoot) RootFs.rename(item.file, name) else FileOps.rename(item.file, name) }
            clearSel(); reload()
            if (!ok) say(R.string.rename_failed)
        }
    }

    fun create(name: String, folder: Boolean) {
        if (!FileOps.validName(name)) { say(R.string.invalid_name); return }
        val viaRoot = rootMode
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) {
                val f = File(path, name)
                when {
                    viaRoot -> RootFs.create(f.path, folder)
                    f.exists() -> false
                    folder -> f.mkdir()
                    else -> runCatching { f.createNewFile() }.getOrDefault(false)
                }
            }
            reload()
            if (!ok) say(R.string.exists_already)
        }
    }

    fun openRoot(i: Item) {
        val app = getApplication<Application>()
        viewModelScope.launch {
            val out = withContext(Dispatchers.IO) { RootFs.readableCopy(i.file, app.cacheDir) }
            if (out == null || !Opener.open(app, out, newTask = true)) say(R.string.no_app)
        }
    }

    fun notify(@StringRes res: Int, vararg args: Any) = say(res, *args)
}

package com.aerostudio.manager.ui

import android.Manifest
import android.content.Intent
import android.provider.Settings
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.AnimationSpec
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.Dp
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.aerostudio.manager.R
import com.aerostudio.manager.core.Perm
import com.aerostudio.manager.core.Prefs
import java.io.File

@Composable
fun AeroRoot() {
    val vm: AppViewModel = viewModel()
    val prefs by vm.prefs.collectAsStateWithLifecycle()
    AeroTheme(prefs) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            AeroScaffold(vm, prefs)
        }
    }
}

private class NavTab(val label: Int, val icon: ImageVector)

@Composable
private fun AeroScaffold(app: AppViewModel, prefs: Prefs) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val ex: ExplorerViewModel = viewModel()
    val tabs = listOf(
        NavTab(R.string.nav_home, Icons.Rounded.Home),
        NavTab(R.string.nav_files, Icons.Rounded.Folder),
        NavTab(R.string.nav_tools, Icons.Rounded.Handyman),
        NavTab(R.string.nav_favorites, Icons.Rounded.Star),
        NavTab(R.string.nav_settings, Icons.Rounded.Settings),
    )
    val openInFiles: (File) -> Unit = { f -> ex.openPath(f); tab = 1 }

    Box(Modifier.fillMaxSize()) {
        Box(Modifier.fillMaxSize().statusBarsPadding()) {
            AnimatedContent(
                targetState = tab,
                label = "tabs",
                transitionSpec = {
                    if (prefs.anim) (fadeIn(tween(240)) + slideInVertically(tween(300)) { it / 20 }) togetherWith fadeOut(tween(120))
                    else EnterTransition.None togetherWith ExitTransition.None
                },
            ) { t ->
                when (t) {
                    0 -> HomeScreen(openInFiles)
                    1 -> ExplorerScreen(ex, app, prefs)
                    2 -> ToolsScreen(openInFiles)
                    3 -> FavoritesScreen(app, prefs, openInFiles)
                    else -> SettingsScreen(app, prefs)
                }
            }
        }
        GlassNavBar(tabs, tab, prefs.anim, { tab = it }, Modifier.align(Alignment.BottomCenter).navigationBarsPadding())
    }
}

/**
 * Floating "glass" bar: translucent gradient, specular edge, shadow and a springy sliding selector.
 * Note: this is not a true backdrop blur (that needs a dedicated library and Android 12+); content simply shows through.
 */
@Composable
private fun GlassNavBar(tabs: List<NavTab>, selected: Int, anim: Boolean, onSelect: (Int) -> Unit, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(34.dp)
    BoxWithConstraints(
        modifier
            .padding(start = 20.dp, end = 20.dp, top = 8.dp, bottom = 12.dp)
            .shadow(18.dp, shape, ambientColor = Color.Black, spotColor = Color.Black)
            .fillMaxWidth()
            .height(70.dp)
            .clip(shape)
            .background(Brush.verticalGradient(listOf(cs.surfaceContainerHigh.copy(alpha = 0.82f), cs.surfaceContainerLowest.copy(alpha = 0.72f))))
            .border(1.dp, Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.32f), Color.White.copy(alpha = 0.05f))), shape)
            .padding(6.dp),
    ) {
        val itemW = maxWidth / tabs.size
        val spec: AnimationSpec<Dp> = if (anim) spring(dampingRatio = 0.55f, stiffness = 420f) else snap()
        val x by animateDpAsState(itemW * selected, spec, label = "pill")
        Box(
            Modifier
                .offset(x = x)
                .width(itemW)
                .fillMaxHeight()
                .clip(RoundedCornerShape(28.dp))
                .background(Brush.verticalGradient(listOf(cs.primary.copy(alpha = 0.40f), cs.primary.copy(alpha = 0.16f))))
                .border(1.dp, cs.primary.copy(alpha = 0.5f), RoundedCornerShape(28.dp)),
        )
        Row(Modifier.fillMaxSize()) {
            tabs.forEachIndexed { i, t -> NavItem(t, i == selected, anim, Modifier.weight(1f)) { onSelect(i) } }
        }
    }
}

@Composable
private fun NavItem(t: NavTab, selected: Boolean, anim: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val spec: AnimationSpec<Float> = if (anim) spring(dampingRatio = 0.45f, stiffness = 500f) else snap()
    val scale by animateFloatAsState(if (selected) 1.14f else 1f, spec, label = "navscale")
    val tint by animateColorAsState(if (selected) cs.primary else cs.onSurfaceVariant, label = "navtint")
    Column(
        modifier
            .fillMaxHeight()
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Icon(t.icon, null, tint = tint, modifier = Modifier.size(24.dp).graphicsLayer { scaleX = scale; scaleY = scale })
        Text(stringResource(t.label), style = MaterialTheme.typography.labelSmall, color = tint, maxLines = 1)
    }
}

@Composable
fun rememberHasAccess(): Boolean {
    val ctx = LocalContext.current
    var ok by remember { mutableStateOf(Perm.has(ctx)) }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val ob = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) ok = Perm.has(ctx) }
        owner.lifecycle.addObserver(ob)
        onDispose { owner.lifecycle.removeObserver(ob) }
    }
    return ok
}

@Composable
fun AccessPrompt(modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}
    Column(
        modifier.padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Icon(Icons.Rounded.Lock, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(40.dp))
        Text(stringResource(R.string.access_title), style = MaterialTheme.typography.titleLarge, textAlign = TextAlign.Center)
        Text(
            stringResource(R.string.access_text),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
        )
        Button(onClick = {
            if (Build.VERSION.SDK_INT >= 30) {
                try { ctx.startActivity(Perm.settingsIntent(ctx)) }
                catch (e: Exception) { ctx.startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)) }
            } else {
                launcher.launch(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE))
            }
        }) { Text(stringResource(R.string.access_grant)) }
    }
}

@Composable
fun AccessGate(content: @Composable () -> Unit) {
    if (rememberHasAccess()) content()
    else Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { AccessPrompt() }
}

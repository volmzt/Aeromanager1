package com.aerostudio.manager.ui

import android.Manifest
import android.content.Intent
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.aerostudio.manager.R
import com.aerostudio.manager.core.Perm
import com.aerostudio.manager.core.Prefs
import java.io.File

@Composable
fun AeroRoot() {
    val vm: AppViewModel = viewModel()
    val prefs by vm.prefs.collectAsStateWithLifecycle()
    AeroTheme(prefs) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            AeroScaffold(vm, prefs)
        }
    }
}

// screens: 0 files, 1 storage, 2 favorites, 3 tools, 4 settings, 5 large files
private fun titleOf(screen: Int) = when (screen) {
    1 -> R.string.nav_home
    2 -> R.string.nav_favorites
    3 -> R.string.nav_tools
    4 -> R.string.nav_settings
    else -> R.string.tool_large
}

@Composable
private fun AeroScaffold(app: AppViewModel, prefs: Prefs) {
    var screen by rememberSaveable { mutableIntStateOf(0) }
    val ex: ExplorerViewModel = viewModel()
    val openInFiles: (File) -> Unit = { f -> ex.openPath(f); screen = 0 }
    val goBack = { screen = if (screen == 5) 3 else 0 }
    BackHandler(enabled = screen != 0) { goBack() }

    if (screen == 0) {
        ExplorerScreen(ex, app, prefs) { screen = it }
    } else {
        Column(Modifier.fillMaxSize()) {
            Surface(color = MaterialTheme.colorScheme.surfaceContainerHigh) {
                Row(Modifier.statusBarsPadding().height(64.dp).padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(goBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, stringResource(R.string.back)) }
                    Text(stringResource(titleOf(screen)), style = MaterialTheme.typography.titleLarge)
                }
            }
            Box(Modifier.weight(1f)) {
                when (screen) {
                    1 -> HomeScreen(openInFiles)
                    2 -> FavoritesScreen(app, prefs, openInFiles)
                    3 -> ToolsScreen { screen = 5 }
                    4 -> SettingsScreen(app, prefs)
                    else -> AccessGate { LargeFiles(openInFiles) }
                }
            }
        }
    }
}

@Composable
fun rememberHasAccess(): Boolean {
    val ctx = LocalContext.current
    var ok by remember { mutableStateOf(Perm.has(ctx)) }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val ob = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) ok = Perm.has(ctx) }
        owner.lifecycle.addObserver(ob)
        onDispose { owner.lifecycle.removeObserver(ob) }
    }
    return ok
}

@Composable
fun AccessPrompt(modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}
    Column(
        modifier.padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Icon(Icons.Rounded.Lock, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(40.dp))
        Text(stringResource(R.string.access_title), style = MaterialTheme.typography.titleLarge, textAlign = TextAlign.Center)
        Text(
            stringResource(R.string.access_text),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
        )
        Button(onClick = {
            if (Build.VERSION.SDK_INT >= 30) {
                try { ctx.startActivity(Perm.settingsIntent(ctx)) }
                catch (e: Exception) { ctx.startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)) }
            } else {
                launcher.launch(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE))
            }
        }) { Text(stringResource(R.string.access_grant)) }
    }
}

@Composable
fun AccessGate(content: @Composable () -> Unit) {
    if (rememberHasAccess()) content()
    else Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { AccessPrompt() }
}

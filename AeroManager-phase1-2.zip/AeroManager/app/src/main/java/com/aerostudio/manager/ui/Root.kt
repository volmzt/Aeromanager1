package com.aerostudio.manager.ui

import android.Manifest
import android.content.Intent
import android.provider.Settings
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.aerostudio.manager.R
import com.aerostudio.manager.core.Perm
import com.aerostudio.manager.core.Prefs
import java.io.File

@Composable
fun AeroRoot() {
    val vm: AppViewModel = viewModel()
    val prefs by vm.prefs.collectAsStateWithLifecycle()
    AeroTheme(prefs) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            AeroScaffold(vm, prefs)
        }
    }
}

private class NavTab(val label: Int, val icon: ImageVector)

@Composable
private fun AeroScaffold(app: AppViewModel, prefs: Prefs) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val ex: ExplorerViewModel = viewModel()
    val tabs = listOf(
        NavTab(R.string.nav_home, Icons.Rounded.Home),
        NavTab(R.string.nav_files, Icons.Rounded.Folder),
        NavTab(R.string.nav_tools, Icons.Rounded.Handyman),
        NavTab(R.string.nav_favorites, Icons.Rounded.Star),
        NavTab(R.string.nav_settings, Icons.Rounded.Settings),
    )
    val openInFiles: (File) -> Unit = { f -> ex.openPath(f); tab = 1 }

    Scaffold(
        containerColor = Color.Transparent,
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surfaceContainer) {
                tabs.forEachIndexed { i, t ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i },
                        icon = { Icon(t.icon, null) },
                        label = { Text(stringResource(t.label), maxLines = 1) },
                    )
                }
            }
        },
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            AnimatedContent(
                targetState = tab,
                label = "tabs",
                transitionSpec = {
                    if (prefs.anim) (fadeIn(tween(220)) + slideInVertically(tween(260)) { it / 24 }) togetherWith fadeOut(tween(120))
                    else EnterTransition.None togetherWith ExitTransition.None
                },
            ) { t ->
                when (t) {
                    0 -> HomeScreen(openInFiles)
                    1 -> ExplorerScreen(ex, app, prefs)
                    2 -> ToolsScreen(openInFiles)
                    3 -> FavoritesScreen(app, prefs, openInFiles)
                    else -> SettingsScreen(app, prefs)
                }
            }
        }
    }
}

@Composable
fun rememberHasAccess(): Boolean {
    val ctx = LocalContext.current
    var ok by remember { mutableStateOf(Perm.has(ctx)) }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val ob = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) ok = Perm.has(ctx) }
        owner.lifecycle.addObserver(ob)
        onDispose { owner.lifecycle.removeObserver(ob) }
    }
    return ok
}

@Composable
fun AccessPrompt(modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}
    Column(
        modifier.padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Icon(Icons.Rounded.Lock, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(40.dp))
        Text(stringResource(R.string.access_title), style = MaterialTheme.typography.titleLarge, textAlign = TextAlign.Center)
        Text(
            stringResource(R.string.access_text),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
        )
        Button(onClick = {
            if (Build.VERSION.SDK_INT >= 30) {
                try { ctx.startActivity(Perm.settingsIntent(ctx)) }
                catch (e: Exception) { ctx.startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)) }
            } else {
                launcher.launch(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE))
            }
        }) { Text(stringResource(R.string.access_grant)) }
    }
}

@Composable
fun AccessGate(content: @Composable () -> Unit) {
    if (rememberHasAccess()) content()
    else Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { AccessPrompt() }
}

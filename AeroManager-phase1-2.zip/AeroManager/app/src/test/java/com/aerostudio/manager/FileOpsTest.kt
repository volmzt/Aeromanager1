package com.aerostudio.manager

import com.aerostudio.manager.core.Conflict
import com.aerostudio.manager.core.FileOps
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File

class FileOpsTest {
    @get:Rule val tmp = TemporaryFolder()

    private fun dirs(): Pair<File, File> = tmp.newFolder("src") to tmp.newFolder("dst")

    @Test fun copyKeepBothDoesNotTouchExisting() {
        val (s, d) = dirs()
        File(s, "x.txt").writeText("new"); File(d, "x.txt").writeText("old")
        val r = runBlocking { FileOps.transfer(listOf(File(s, "x.txt")), d, false, Conflict.KEEP_BOTH) {} }
        assertEquals(1, r.done)
        assertEquals("old", File(d, "x.txt").readText())
        assertEquals("new", File(d, "x (1).txt").readText())
        assertTrue(File(s, "x.txt").exists())
    }

    @Test fun replaceOverwrites() {
        val (s, d) = dirs()
        File(s, "x.txt").writeText("new"); File(d, "x.txt").writeText("old")
        runBlocking { FileOps.transfer(listOf(File(s, "x.txt")), d, false, Conflict.REPLACE) {} }
        assertEquals("new", File(d, "x.txt").readText())
    }

    @Test fun skipLeavesExisting() {
        val (s, d) = dirs()
        File(s, "x.txt").writeText("new"); File(d, "x.txt").writeText("old")
        val r = runBlocking { FileOps.transfer(listOf(File(s, "x.txt")), d, false, Conflict.SKIP) {} }
        assertEquals(1, r.skipped)
        assertEquals("old", File(d, "x.txt").readText())
    }

    @Test fun moveRemovesSourceAndLeavesNoTempFiles() {
        val (s, d) = dirs()
        File(s, "a").mkdirs(); File(s, "a/b.txt").writeText("data")
        val r = runBlocking { FileOps.transfer(listOf(File(s, "a")), d, true, Conflict.KEEP_BOTH) {} }
        assertTrue(r.errors.isEmpty())
        assertFalse(File(s, "a").exists())
        assertEquals("data", File(d, "a/b.txt").readText())
        assertTrue(d.walkTopDown().none { it.name.endsWith(".aero-part") })
    }

    @Test fun copyFolderIntoItselfIsRejected() {
        val (s, _) = dirs()
        val inner = File(s, "inner").apply { mkdirs() }
        val r = runBlocking { FileOps.transfer(listOf(s), inner, false, Conflict.KEEP_BOTH) {} }
        assertEquals(FileOps.ERR_SELF, r.errors.single().code)
    }

    @Test fun uniqueNameHandlesExtensionsAndDotfiles() {
        val d = tmp.newFolder("u")
        File(d, "a.tar.gz").writeText("1"); File(d, ".hidden").writeText("1")
        assertEquals("a.tar (1).gz", FileOps.uniqueName(d, "a.tar.gz").name)
        assertEquals(".hidden (1)", FileOps.uniqueName(d, ".hidden").name)
    }
}
